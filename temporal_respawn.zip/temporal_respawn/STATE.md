# STATE.md — Temporal Exchange canonical ledger

**This is the single source of truth, append-only.** Read at session start; append at
session end. Never silently rewrite history — supersede with a new dated entry. This
file replaces the chat-era snapshot protocol and the archived `session_tree_note`.

---

## CURRENT TRUTH (one line)
The interface stack is verified end-to-end in Lean (curve → value → storage → solvency,
type-wired); the engine instantiation of those contracts and the GH curve swap remain
the open engineering fronts.

## MODE
Default BRAINSTORM. Edits to canonical files require operator "do a pass" + a free lock.

## WRITE-LOCKS (file | holder)   — claim by appending; one holder max
- formal/temporal_lean_verified/** | (free)
- project/engine/temporal_mvp_LIVE.html | (free)
- project/temporal_paper_draft.md | (free)
- project/temporal_formal_spec.md | (free)
- STATE.md | (append-only; no exclusive lock)

---

## IN HAND — machine-checked (formal/, Lean 4.28.0 + Mathlib v4.28.0)

Three modules, one project, all key results report only `propext`/`Classical.choice`/
`Quot.sound`. Build + axiom check: `formal/audit.sh` §6; statement re-check:
`formal/verify_math.py`; full audit dossier: `formal/MANAGER_VERIFICATION.md`.

- **AMMCurve.lean** — `AMMCurve` validity gate (monotone/convex/coercive as proof-
  obligation fields); `poolValue_concaveOn` (universal short-gamma); `hedge_gap_concaveOn`;
  instances `cpmm`, `expPool`; two `example`s proving free transfer.
- **Temporal.lean** — `PassiveSystem` + proved `passivity`/`solvent`/`closed_cycle`;
  `TemporalAMM` with B1(`solvent`)/B3(`arb_nonneg`)/B4(`ledger`) as hypotheses;
  `toPassiveSystem` + corollaries. (Earlier prover run; only edit was 3 `noncomputable`.)
- **Seam.lean** — the join. `intrinsic` + `intrinsic_concaveOn` (short-gamma reaches
  storage); `CurvePool` (equity = intrinsic(price)+support, B1 = "port covers concave
  deficit"); `toTemporalAMM` + re-exported guarantees; `demoPool` instance;
  `reserves_have_no_floor` (port is *necessary*).

### Honest boundaries on the above (do not blur)
1. Solvency is **conditional** on B1/B3/B4 — hypotheses, not discharged vs. the engine.
   "Port pays" is an external-hedge assumption. `reserves_have_no_floor` shows the port
   *necessary*, not *sufficient*.
2. Lean dynamics are **abstract contracts**, not the HTML engine's numeric formulas.
3. Instances are `cpmm`(=equal-weight Balancer) + `expPool`; weighted Balancer / GH not
   instantiated (mechanism-of-transfer is what's proven).
4. Compile is **trusted-from-prover** until built locally.

---

## OPEN THREADS (what | next-actor)
1. **Engine ⊢ contracts** — show the production HTML engine instantiates B3/B4/B1 with
   its real trade/funding formulas (turns conditional solvency into engine-grounded).
   *Biggest gap.* | research lead + prover
2. **GH curve swap in the engine** — replace Balancer-style barrier curve with GH
   (generalized-hyperbolic, γ>1). Per the broader project notes, three "barrier
   remnants" were outstanding: slippage price still on barrier slope; curve-drawing layer
   still Balancer weight-form; equilibrium marker still barrier arb point. Verify current
   engine state before acting — the bundled `temporal_mvp_LIVE.html` is the May-28 mount
   snapshot; the live branch per notes is `v25_gh` (may live in CTO staging / Drive). | intern + tester
3. **Weighted-Balancer / GH as Lean instances** — instantiate `AMMCurve` for the real
   curve families to exercise the gate beyond cpmm/expPool. | prover
4. **Self-sandwich / path-dependence** — known empirical engine leak (atomic net-zero
   band harvests own price impact; opening order swings payout ~14%). Real fix known:
   settle close against the oracle/anchor-frame mark, not the live displaced pool. It is
   an interface violation (settlement reaching past its contract). PARKED by operator;
   reachable only atomically under continuous arb (standard MEV class). | parked
5. **Funding/hedge-cost inequality** (does priced funding cover realized hedge cost) —
   PARKED; rests on extrinsic factors (external perp-dex hedge + fee policy). | parked
6. **Paper pipeline** — AFT 2026 submitted (notification ~July 15 2026). WINE 2026 and
   FMBC 2027 (Lean paper, OASIcs + JLAMP) targeted. Singh et al. (LVR-as-continuum-of-
   perpetual-options) is the must-cite neighbor for rebuttal. | paper

---

## LOCKED DECISIONS
- Scaffold's purpose = math **propagates consistently across all interfaces**; each
  layer reads only the contract of the layer below (curve→price→value→storage→guarantees).
  The self-sandwich bug was exactly a violation of this (settlement bypassing the price
  contract) — so the discipline both propagates consistency and prevents that bug class.
- Solvency split: **WAY-1** (trader-side pricing correctness / closed-book identity) is
  what we *prove*; **WAY-2** (pool-can-pay = fees vs LVR + external hedge) is an
  *assumption* resting on extrinsic factors.
- No kinetic energy in the dynamical object: overdamped spring-damper, latency is
  capacitive (RC), not inductive — passivity, not conservation. Oracle = drive,
  funding = conservative spring/sensor, arbitrage = the dissipative damper (LVR leak).
- Short-gamma is **universal** for any valid convex curve; convexity is always
  synthetic/funded. Rebase-invariance is **orthogonal** to curve shape (mark reads only
  ratios). Balancer cannot reach γ>1; GH (power-sum) can.
- Value-as-envelope encoding (`poolValue = inf of affine`) deliberately needs convexity,
  not differentiability; the explicit marginal-price *derivative* obligation enters only
  when/if a finer price→value contract is built.

## PARKED (operator's call — document, don't reopen unprompted)
- Atomic self-sandwich + path-dependence (fix known; see thread 4).
- Funding/hedge-cost sufficiency inequality (thread 5).
- Jump/gap risk (scoped out under low-vol/continuous-move assumption + small tail buffer).
- Finite-maturity (expirable) option decomposition over the perpetual strike continuum
  via a time-BL kernel Φ — genuinely outside the static span (exponent bends to r(λ)≠Γ);
  flagged as a real open theory question, not on the critical path.

## PROVENANCE — three prover runs feeding formal/
- Temporal.lean — abstract passivity core + engine reduction (only edit: 3 `noncomputable`).
- AMMCurve.lean — curve gate + short-gamma bridge + 2 instances (all sorries closed clean).
- Seam.lean — the join (provided proofs compiled; `reserves_have_no_floor` closed with
  explicit witness `p=|b|+k+2`).
All Lean 4.28.0 + Mathlib v4.28.0. A separate prover run on no-arb-as-symmetry (the C3
reflection result) exists but is NOT in this package.

---

## LOG (append below; newest last; date | role | what changed)
- 2026-06-06 | research lead | Respawn package assembled. Formal line (3 modules) verified
  and audited; manager verification package produced; this ledger seeded. Stack is
  type-wired curve→solvency. Next gap: engine ⊢ contracts (thread 1).
