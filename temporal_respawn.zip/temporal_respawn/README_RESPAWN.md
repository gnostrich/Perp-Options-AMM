# Temporal Exchange — Respawn Package

This is a cold-start kit for a **Claude Code agent** (the research lead) and its
collaborators (manager, implementation intern, tester, paper; plus the external Lean
prover, Aristotle) working on **Temporal Exchange** — a DeFi liquidation-protected
perpetual-options protocol built on one dynamic-weight CFMM.

Unzip into your workspace root. `CLAUDE.md` is written to be auto-loaded by Claude Code.

## Start here (read order)
1. **`CLAUDE.md`** — the operating brain. Identity, environment, discipline, bootstrap.
2. **`STATE.md`** — the single canonical ledger: current truth, what's in hand, open
   threads, locked decisions, what's parked. *Append-only.* Read at every session start.
3. **`ORIENTATION.md`** — the math, the interface-stack architecture, the engine
   findings, the solvency stance, the publication context, the artifact/version map.
4. **`roles/<your-role>.md`** — your specific brief.

## What's in the box
```
CLAUDE.md                 auto-loaded operating context
STATE.md                  canonical append-only ledger (source of truth)
ORIENTATION.md            deep context (math, architecture, findings, boundaries)
roles/
  manager.md              independent verifier + coordinator
  intern.md               implementation intern ("grunt") — engine passes, file-safety
  prover_aristotle.md     external Lean prover handoff contract
  tester.md               regression oracle + browser confirmation
  paper.md                writeups + publication pipeline
formal/                   THE VERIFIED LINE (machine-checked, in hand)
  temporal_lean_verified/ Lean 4.28.0 + Mathlib v4.28.0 project (3 modules + Audit)
  audit.sh                mechanical source/token/axiom scan + build instructions
  verify_math.py          independent numerical re-check of the proven statements
  MANAGER_VERIFICATION.md  claim-by-claim audit dossier (file:line map, boundaries)
  prompts/                the three working Aristotle prompt templates
project/                  broader durable artifacts
  temporal_formal_spec.md
  temporal_paper_draft.md
  Temporal_Paper_AfT_2026_v6.docx
  mvp_v5_brainstorm.md
  rebasing_logic_note.md
  recipe_html_blob_editing.md      <- file-safety recipe; read before any engine edit
  engine/temporal_mvp_LIVE.html    <- canonical MVP (May-28 snapshot; confirm vs live branch)
history/                  archived chat-era record (NOT canonical now)
  session_tree_note_ARCHIVE.md
  transcript_journal.txt           <- index to /mnt/transcripts (~20MB, not bundled)
```

## The one-sentence status
The interface stack is verified end-to-end in Lean — curve → value → storage → solvency,
type-wired, with the funding port proven *necessary* — while the engine's instantiation
of those contracts and the GH curve swap remain the open engineering fronts. The single
real-world assumption ("the port pays") sits in plain sight as one named hypothesis.

## Two things to internalize before doing anything
1. **Verify, don't trust.** Lean compile here is *trusted-from-prover* until you build it
   (`formal/audit.sh` §6). The math is independently re-checkable (`formal/verify_math.py`).
2. **Brainstorm by default.** No edits to canonical files (engine, Lean, paper) until the
   operator says **"do a pass"** and the file's WRITE-LOCK in `STATE.md` is free.
