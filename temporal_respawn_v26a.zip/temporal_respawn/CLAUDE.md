# CLAUDE.md — Temporal (GH branch), Claude Code agent memory

You are working on **Temporal Exchange**: a single-file HTML simulator for a DeFi
options-AMM whose invariant prices `value ∝ S^(−γ)` (γ>1) across a continuum of
perpetual-option strikes, with a generalized-hyperbolic (GH) reserve curve. The
deliverable is one HTML file; a CTO propagates the math to a Go backend separately.

This file is your standing orientation. Read `STATE.md` next for current truth.

## 0. The store is now the filesystem (this supersedes the chat protocol)
In the prior chat-session world, state lived in a `TEMPORAL-CONTEXT-LEDGER` snapshot
re-emitted at the end of every reply, recovered by searching sibling transcripts.
**That is obsolete here.** In Claude Code the repository/filesystem is the durable
store. Concretely:
- `STATE.md` is the single source of truth — lineage, head build, open threads, owners.
  Update it at the end of any meaningful unit of work. Do not re-paste a snapshot per reply.
- If `git` is available, commit logical units with honest messages; the log is the history.
- Briefs, findings, and decisions are **files**, not chat text. Round-trips between
  collaborators are explicit file handoffs, not implied.
- **Never claim a file persisted unless it is actually written/committed.** The old rule
  "the snapshot is the only durable record" becomes "the committed/saved file is."

## 1. Roles
Sessions historically split into: **manager** (relay/architect — Rohan), **implementation
intern** ("grunt"), **prover** ("Aristotle", Lean 4), **tester** (browser/UI). In this
environment you may *be* one of these or coordinate several. Infer your role from the task;
ask one short question only if genuinely ambiguous. Default posture is **BRAINSTORM** — no
edits to a canonical file until the operator says "do a pass."

## 2. Non-negotiable discipline
- **Brainstorm-first.** No edits to any canonical build without an explicit "do a pass."
  Honest readiness assessment before risky edits; an incomplete careful stop beats a rushed
  green run.
- **Independently verify everything.** Re-derive numbers in Node/Python; never rubber-stamp
  a submission (your own or a colleague's). The cleaner and more confident a result looks,
  the harder you check it. The canonical cautionary tale: a wrong slippage fix shipped by
  trusting a mislabeled comment; it was caught by re-deriving (see §5, the e^μ gotcha).
- **Surface findings; never paper over.** If output disagrees with the spec or with geometry,
  that *is* the finding — report it with the diagnostic (numbers, tables, the failing case).
  Do not improvise a fix to a semantics question; present options and let the architect decide.
- **Own mistakes plainly.** No self-abasement, no defensiveness — acknowledge, fix, move on.
- **STOP-ON-RED.** Any file-safety failure → stop, report, and do NOT list the build as a
  deliverable/package.

## 3. File-safety (the wall — applies to EVERY edit of the HTML)
The HTML embeds two base64 blobs (a webp background, an svg logo). Corrupting them or the
script structure silently breaks the app.
- **Blobs never go through chat and are never hand-edited.** Edit via on-disk Python splices
  that read the file, do uniquely-asserted `str.replace` (assert each anchor fires exactly
  once), and write it back.
- **After every edit, confirm:** blob md5s unchanged (canonical set below); all 3 `<script>`
  blocks parse (`node --check` and/or `new Function`); the engine IIFE is intact; no line
  inside a script exceeds ~50k chars (no blob-in-script); no function signatures changed
  unless that is the explicit task.
- **Canonical blob md5s:** webp (line ~74, len 273917) `ab663f5c26f2a461c5b0ef1421d0ad74`;
  svg (line ~1060, len 5240) `c505b08ad0e4c6b0fb9e64e9679fe291`. A ledger elsewhere lists
  `8d2e1a84`/`1b320fc5` (len 205398/3875) — **that is the optimizer-shrunk "broken cut"; do
  NOT restore it.** The files are canonical; the ledger is stale (open thread: reconcile).
- **No asset optimizer / minifier, ever.** That is what broke the last cut.
- See `splices/SPLICE_METHOD.md` for the exact recipe and `splices/*.py` for worked examples.

## 4. Environment constraints (state them honestly, don't fake)
- **Math: fully verifiable here.** Sandbox the `<script id="engine">` block in Node
  (`vm.runInNewContext`); `Engine.ghCalibrate(X0,Y0,mp0,γ)` opens a pool, everything else
  follows. `verify/` has the harnesses; `verify/run_all.sh` runs them against HEAD.
- **Lean: trusted-from-prover.** The Lean toolchain may be unreachable (it 403'd before). If
  you cannot compile, say so; treat prover results as trusted-from-prover until independently
  re-run. Formal spec in `notes/temporal_formal_spec.md`.
- **Browser/UI: tester-confirmed.** Playwright needs `storage.googleapis.com` on the network
  allowlist. If you cannot run a browser, the curve/marker/slippage *math* is still checkable
  in Node, but the visual is the tester's call — say "tester-confirmed", don't assert pixels.
- Shell is `sh` (no process substitution `<(...)` — use plain `diff a b`). Node v22.

## 5. THE gotcha (internalize — it caused the slippage bug)
**`getMP_raw` is the carry PRICE COORDINATE, not the geometric reserve slope.** It equals the
oracle at equilibrium (that is what the no-arb gate and `arbitrageToOracle` target). The actual
reserve slope is `|dy/dx| = getMP_raw · e^(−ghMu)` — they differ by `e^ghMu` exactly (11.7 / 44.5 /
749 / 13780 at γ = 1.5 / 2 / 3 / 4; it explodes with γ). The in-code comment used to mislabel it
`|dy/dx| raw`; that is fixed in HEAD. **Never use `getMP_raw` as a slope.** Anything comparing a
price against a geometric Δy/Δx (slippage %, $-cost, tangent angles) must use
`getMP_raw · e^(−s.ghMu)` (call it `mpGeom`). Read `getMP_raw` off `s.ghMu` per-state; never
hardcode 44.5 and never default `ghMu` (a missing `ghMu` should produce NaN loudly, not `e^0`).

Why gates didn't catch it: the 7 gates are mostly **self-consistency** (round-trip to oracle,
rebase /r, bounds, monotone, open). The one true **accuracy** gate is `value ∝ S^(−γ)` (G4); the
ITM work adds a **seam gate**. A price/slope conflation passes every self-consistency gate.

## 6. Locked architecture (don't reopen unless the architect does)
- Curve-baked **GH only**, **γ>1, no barrier** (barrier's exponent is outside the GH family; δ
  doesn't recover it). Only 4 engine functions are curve-dependent: `getMP_raw`, `tradeUpdate`,
  `arbitrageToOracle`, `rebase`. `getSNorm`=(x−α)/α carries convexity via X∝S^(−γ); `getDepth` is
  display-only/stale.
- **Carry P = Ny/Nx** is load-bearing: `u = log(price) − log P` at calibration and arb; rebase
  recomputes `P → P/r`. GH state is scalar params on the pool (`ghP, ghNx, ghNy, ghM, ghMu, ghAh,
  ghBh, ghDelta`); the CDF table lives in a module cache keyed by shape, re-derived on load
  (pool stays serialization-safe).
- **Slippage** references the geometric marginal `mpGeom = getMP_raw·e^(−ghMu)`; the **%** is
  basis-independent (e^μ cancels); the **$** is Layer-1 reserve-USD for now (Layer-2 honest-dollar
  is a deferred follow-up via the existing carved-perp settlement chain — reuse it, don't improvise).
- **ITM/American exercise** (next work): continuation `c·sNorm` runs PAST the strike to the
  smooth-pasting free boundary `sNorm* = θ·((γ+1)/γ)^γ` (price `S* = K·γ/(γ+1)`), then exercise pays
  intrinsic-from-strike. Closed form, no new params; drops the redundant "Eff strike" column. Spec:
  `specs/SPEC_itm_exercise_smoothpaste_NEXT.md`. §6 of that spec: settlement exercise lives entirely
  in stage 2; the stage-2→3 dollar conversion is UNCHANGED — if it seems to need an exercise-specific
  branch, **stop and report**.
- Funding is the slope-deviation ratio vs the w=½ anchor at the strike ray — orthogonal to
  intrinsic, untouched by the ITM change.

## 7. Where things stand (summary; `STATE.md` is authoritative)
HEAD = `builds/HEAD_temporal_mvp_v26a.html` (md5 `89ae89e9`): GH swap + v26a fixes + slippage
units fix, 7 gates green. Owed: manager independent verify, then tester browser re-run (slippage
display + frame re-fit + dropped column). Then **v26b** = ITM/American on this base.

## 8. Working with colleagues in this environment
- Coordinate through `STATE.md` (open threads + owners) and file briefs — not implied context.
- If you pick up a thread, mark it in `STATE.md`; when you finish, update status and hand off
  explicitly (who acts next).
- Trust-but-verify peers: re-run their numbers before building on them. Prover output is
  trusted-from-prover until you re-run; tester visual is authoritative for UI.
- Keep a single canonical build (HEAD); never fork the curve twice — fixes land before behavior
  changes so the draw layer stays coherent (this is why v26a fixes preceded v26b ITM).
