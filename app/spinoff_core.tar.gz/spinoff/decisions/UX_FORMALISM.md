# UX FORMALISM — the standing framework for Temporal's interaction surface

_Owner: the `ux` agent (`.claude/agents/ux.md`). Established by the manager on operator entry 585.
This is the binding document: placements and costs are decided **by rule** here, not re-argued per
change. If a rule does not decide a case, extend the rule — do not make a one-off placement._

Operator's instruction, verbatim:

> take a call on all open UX questions, retain a persistent agent to formally check optimise steps /
> glances across all UX lifecycle possibilities and to grasp the possible design choices in terms of
> representation on UX so its not an idiosyncratic task to modify each time like the payout thing vs
> account-in etc. these should be taken in-stride by persistent UX agent using the appropriate
> formalisms so I can abstract away interactions with the core iygwim

---

## 0. TIERS — what is forced, what is decided, what is free (operator entry 588)

> but yes importantly try to distinguish whats economically invariant vs whats representational /
> interaction surface choice iygwim

**Every item in this document carries a tier. Nothing may be optimised across tiers.** This is the
discipline that stops a surface "improvement" from quietly breaking an economic truth, and stops a free
choice from being treated as sacred.

| tier | what it is | who may change it | UX agent's duty |
|---|---|---|---|
| **INVARIANT** | forced by the economics or by an accounting identity. It could not be otherwise without the venue being a different venue. | nobody — it is a fact about the design | **represent it faithfully.** Never trade it away for cost. A surface that misrepresents an invariant is INVALID at any step count |
| **RULED** | operator policy. It *could* have been otherwise; the operator decided. | the operator only | obey. Do not re-open, do not re-derive, do not "improve" |
| **CHOICE** | genuinely free representational or interaction decision | the `ux` agent, under §1–§4 | **this is the only tier you optimise.** Cost it in steps and glances and pick |

**The test:** ask *"could this be otherwise and the venue still be the same venue?"*
No → INVARIANT. Yes, but the operator has spoken → RULED. Yes, and nobody has → CHOICE.

### 0.1 The invariants, gathered
These are facts, not decisions. UX represents them; UX never negotiates them.
1. **No naked option.** Every option is carved from a perp. (⇒ the perp line always exists.)
2. **The bundle is atomic.** Option/spread + sliver perp open together, close together, in full.
3. **A carved perp is still a perp** and retains every perp property. (⇒ no sliver type in the model.)
4. **Liquidation is account-level**, perps and perp-options together, LP excluded, 50× cap.
5. **A close is a trade** at the aggregate with the closer's own curve excluded — not intrinsic
   settlement. (⇒ a close has a price, and therefore an expiry.)
6. **Derived quantities are not user inputs:** level (oracle → natural map → S̄), close price, released
   sliver, fill routing (pro-rata by capital), put price (parity `C − P = −k`).
7. **Accounting identity:** perps tab + carved lines = the account's whole perp position, always.
8. **Where no counterparty exists, no price exists.** (LP sole maker at a strike.)

### 0.2 The commonest error this tier system prevents
A misrepresentation of an invariant is **not** a trade-off against cost — it is invalid. Showing a
per-position liquidation price when liquidation is account-level is not "one extra glance of comfort",
it is **false state**, and no step saving anywhere else compensates for it. Conversely, arguing about
whether EARN is a route or a tab as though it were sacred wastes the operator's time on a CHOICE.

---

## 1. The objective function

Two currencies, both counted, neither traded off silently.

| currency | unit | what it measures |
|---|---|---|
| **steps** | KLM/GOMS operators — point, click, keystroke, mental-prepare, system-wait | what the user must **do** |
| **glances** | distinct information lookups — a fixation on a value not already in working memory | what the user must **find** |

```
cost(task) = steps(task) + glances(task)          both reported separately, never netted
```

**A change that cuts steps while adding glances is usually a regression.** Collapsing two screens into
one modal removes a navigation step and adds three glances if the modal hides what the previous screen
showed. State both numbers or the claim is not made.

## 2. The lower bound

```
steps_min   = (irreducible inputs not already in context) + 1 commit
glances_min = |decision-relevant state at the moment of commit|
```

**Irreducible input** = information the user genuinely must supply; a degree of freedom that cannot be
defaulted, derived or inferred. Known **derivables** in this venue, none of which may cost a step:

| quantity | derived from |
|---|---|
| quoting level | oracle vol → natural map → S̄ |
| close price | the aggregate, closer's own curve excluded |
| perp sliver released on close | the option size closed |
| fill routing | pro-rata by capital — there is no routing choice |
| put price | parity `C − P = −k` from the call |

**Not a derivable — a basis statement (operator entry 592):** an option price is a **fraction of spot**
*and* a function of where on the curve it sits, so a position's value moves in underlying terms for two
reasons at once — spot moving, and moneyness moving along the curve. Any P&L or value column must state
its basis or it reads as a bug. Handled by §4.3.

## 3. THE HARD CONSTRAINT — no decision may be made blind

You are **not** minimising cost. You are minimising cost **subject to**: a step or glance may not be
removed if it is the only place the user sees state needed for the next decision.

> A design that removes cost by hiding decision-relevant state is **INVALID**, not optimal.

Corollary — **mirroring**: a quantity whose home is elsewhere must still be *co-present* with any
control whose outcome it determines. Home is set by §4; co-presence is set by this rule and overrides
it.

### 3.1 Where MORE cost is correct
Irreducible by safety, not to be optimised away:
1. **Firm-quote acceptance.** An RFQ quote is a price with an expiry; accepting is a distinct act.
2. **Close quotes.** A close is a trade at the aggregate (own curve excluded), so it has a price.
3. **Carve disclosure.** Writing an option removes notional from the perps tab. That transfer is shown
   before commit, always.
4. **Anything moving account-level liquidation risk.** Perps and perp-options liquidate together in
   one account (~50× cap; LP excluded). A change in headroom is disclosed at commit.

## 4. REPRESENTATION TAXONOMY — where a quantity lives

This is the part that stops each change being an idiosyncratic argument. Classify on three axes; the
first two give the **home**, the third gives any **mirror**.

**Axis A — ownership:** does it belong to a *position*, or to the *account*?
**Axis B — persistence:** is it a **stock** (standing state, true until changed) or a **flow** (an
event that happened at a time)?
**Axis C — decision-relevance:** is it needed *at the moment of* some commit? If yes, mirror it next to
that control regardless of home (§3).

| A × B | home | form |
|---|---|---|
| position × stock | **position row column** | a cell on the row it belongs to |
| position × flow | **position row, expandable** | event under its own row; row shows the running total |
| account × stock | **account strip** | always-visible, never behind a tab |
| account × flow | **ledger / event feed** + a toast at the moment it happens | itemised, with a pointer back to the position that caused it |

### 4.1 The worked case the operator named: payout vs account-in
A close payout is `account × flow` → its **home is the account ledger**, with a toast at the moment of
credit, and a **back-pointer to the closing position**. It is *also* decision-relevant at the close
commit, so by §3 the *estimated* payout mirrors into the close ticket. It does **not** become a
permanent column on the position row, because it is a flow, not a stock.

That is the rule. It settles the same question for close P&L, funding credits, fee rebates, liquidation
proceeds and LP accruals without re-arguing any of them.

### 4.3 Same home, different basis — the `origin` axis (operator entry 589)
Two rows can be economically different objects and still belong in the **same table**. Taxonomy §4
places by ownership × persistence, and an LP accrual and a trader position are identical on both axes —
so they share a home. What differs is the **basis** of some columns:

| column | trader position (`origin:"opened"`) | LP accrual (`origin:"lp"`) |
|---|---|---|
| notional basis | `size × entryPrice` — a real entry | **mark** — an accrual has no entry price |
| line 1 (the carved perp) | the trader's own perp | **pro-rata share of the counterparty's perp** |
| close | closes the bundle | closes the LP's share of it |

**Rule: do not split the table; state the basis.** A separate LP table would duplicate every column and
force a mode-switch to see total exposure. An `origin` column plus a filter checkbox costs one glance
and keeps one total. The reference reached the same answer independently — `origin?: "opened" | "lp"`
on the contract and `isLpRow` branching only where the *basis* differs, never the placement.

### 4.2 When the taxonomy does not decide
Extend it and record the new rule here. Do not place by taste and move on — a one-off placement is the
failure mode this document exists to prevent.

### 4.4 Curve-valued state lives ON the curve (ux, build-39 review — the dormancy case)
A quantity defined **per strike over a posted curve** (dormancy, depth, spread, fill density) is
`position × stock` with a functional index: its **home is the curve rendering itself** — the drawn
curve is the "row" it belongs to. Scalar aggregates ("N% of strikes live") are **mirrors** — legal as
summaries, **never as replacements**: a scalar that replaces the per-strike form leaves every
*where*-decision (where to requote, where depth thins) blind, which §3 forbids. Applied first to the
dormancy divider (Q16); applies without re-argument to any future per-strike quantity.

### 4.5 Simulation parameters never wear the user-control grammar (ux, build-39 review)
A control that changes the **simulated world** (maker divergence, realised vol, turnover, other
makers' behaviour) is not a user decision and must not be rendered in the same control grammar or
proximity as trade inputs — never inside a commit card. Home: one visually distinct, collapsed
SIMULATION surface (omitted entirely from an end-user build). Rationale: a world-control adjacent to
a commit reads as a trade parameter, adding a false glance to every commit and inviting mis-touch.
Applied first to the maker-divergence dial and the Market & risk sliders (Q17).

## 5. DECISION RECORD

Rulings are permanent. A question answered once is not re-opened without new information. `manager`
entries are the manager's calls on operator entry 585; the `ux` agent owns everything after.

| # | question | ruling | tier | rule applied | by |
|---|---|---|---|---|---|
| Q1 | How many portfolio lines, and what are they? | **RULED BY THE OPERATOR (entry 587): 5 lines MAX, exactly 1 of which is the carved perp** — so 4 option lines + 1 perp. My earlier ruling said 4 total and was one short. Manager's reading of the 4: a vertical spread can be constructed on either side, so bought-inner · bought-outer · sold-inner · sold-outer, with the total as a footer rather than a line. **Flagged for one word of confirmation — I inferred the composition, the operator only fixed the count.** | INVARIANT (leg count) / **CHOICE** (row grouping) | §7 the perp line always exists, because no option can exist unbacked (entry 587). | **operator** (count) / manager (composition, provisional) |
| Q2 | Is EARN a top-level route or a ticket tab? | **Top-level route.** | **CHOICE** | LP is a distinct persona with its own lifecycle (post curve → inspect apportionment → withdraw), not a mode of trading. Burying it in a ticket costs a mode-switch on every LP task. | manager |
| Q3 | Per-position liquidation price, or account-level only? | **Account-level only.** No per-position liq price anywhere. The ticket shows the **marginal effect of this trade on account headroom**. | INVARIANT (account-level) / **CHOICE** (what the ticket shows instead) | §3 — a per-position liq price when liquidation is account-level is *false* decision-relevant state. Showing it is worse than showing nothing. | manager |
| Q4 | Partial close of an option? | **RULED BY THE OPERATOR (entry 587): NO. Overturns my ruling.** "all perp options or vertical spreads opened bundle at once full closed together w slover perp" — the bundle is the unit. It opens at once and closes in full, together with its sliver perp. No fraction slider. | **INVARIANT** — bundle atomicity | The bundle is atomic. **This removes the core consequence I had flagged:** the carve record does NOT need to be fractional or mutable, which is simpler than what I proposed. | **operator** |
| Q5 | Does the carved sliver accrue perp funding? | **RULED BY THE OPERATOR (entry 586): yes — a carved perp is still a perp and retains everything a perp has.** Line 1 is a full perp row with the *same columns as any perp*, funding included. No reduced "sliver" row type, and no new object type in the model. | **INVARIANT** — a carved perp is a perp | §7 — the carve is a display/earmarking operation, not an economic one. | **operator** |
| Q6 | Can a trader write an option without holding the perp? | **INVARIANT, operator entry 587: "no option can be sold without a perp its carved from."** There is no naked option, ever. The composite confirm stands as the low-step route *because* it creates the perp and carves it in one act — it satisfies the invariant rather than bypassing it. | **INVARIANT** (no naked option) / **CHOICE** (composite vs two tickets) | §7. The invariant is also why line 1 always exists. | **operator** (invariant) / manager (composite) |
| Q7 | Closing a perp that has slivers standing against it? | **Compound close** — "close everything on this perp", slivers itemised in the confirm. Not fail-closed-with-a-link. | **INVARIANT** — follows from atomicity; there is no other close | §2 — fail-closed costs more steps for no safety gain once the compound action is disclosable. | manager |
| Q8 | Does a taker see maker-side detail? | **No.** Aggregate only. Your own leg is itemised only when you are yourself a maker in that fill. | **RULED** — operator entry 566 | Operator entry 566 ("you cant see individual makers only self and aggregate") binds the taker too — a taker seeing who filled them leaks the same information. Matches shipped behaviour. | manager |
| Q9 | Quote validity window? | **Expiry with a visible countdown; on expiry, re-quote requiring re-accept. Never silently re-price.** Placeholder 10s pending real latency data. | INVARIANT (expiry exists; never silently re-price) / RULED (duration) / **CHOICE** (countdown UI) | §3.1(1). The *behaviour* is the ruling; the number is a parameter. | manager |
| Q10 | 40× or 50×? | **50× only.** Operator entry 587: "4050 idk what" — the 40 has no provenance; it was not a design decision, it was an unexplained literal in my code. Removed. If a warn band is wanted the operator picks the number; until then there is one threshold. | INVARIANT (50× is the cap) / **CHOICE** (whether a warn band exists at all) | §3 — a threshold nobody can source is not decision-relevant state, it is noise. | **operator** (40 disowned) / manager (removal) |
| Q11 | LP mark/close when the LP is the only maker at a strike? | **Mark** falls back to the oracle-derived curve (it exists independently of any maker). **Close** reads "no counterparty — cannot close". | **INVARIANT** — no counterparty, no price / **CHOICE** (the wording) | §3 — inventing a close price where no counterparty exists is fabricated decision-relevant state. The oracle is a real, already-present source; a close price would not be. | manager |

| Q12 | Where does the LP's own position live? | **Earn.** Capital, posted curve, bias, mode. | **CHOICE** (consistent with Q2) | LP persona owns its own route. | **operator** entry 589 |
| Q13 | Where do LP-accrued fills show? | **Under the perp-options section, in the same table as trader positions**, disambiguated by an `origin` column plus a checkbox filter. | INVARIANT (they are economically different objects and must be distinguishable) / **CHOICE** (column + checkbox as the mechanism) | §4 places them identically — same ownership, same persistence. §4.3 handles the basis difference. Reference already carries `origin?: "opened" \| "lp"` (`portfolio.ts:56,166,228,293`) and `isLpRow` branching (`tableContainer.tsx:506,528,621,694`). | **operator** entry 589 |
| Q14 | What is line 1 on an LP-accrued row? | **A perp-equivalent line for calculation and row consistency — NOT an economic claim** (operator entry 592). An LP is accountable to the **bundled net option / vertical-spread P&L only**; the perp leg does not enter its payout. My earlier reading — "a pro-rata claim on the counterparty's perp" — was **wrong**, and the operator corrected it: there is no claim. | **INVARIANT** | The no-naked-option invariant (§7.1) holds from both sides: the trader's option is carved from *their* perp, and the LP's accrual is backed by a pro-rata claim on that same perp. Nothing is unbacked, and no LP is required to hold a perp. | **operator** entry 589 |
| Q15 | How is the Earn total aggregated? | **A duration triple on the STRIKE axis** (operator entry 590: "like portfolio duration but on strike* (not maturity)"). Three numbers, not one: **exposure** `Σ Δᵢqᵢ` in ₿-perp · **strike duration** `K_D = Σ wᵢkᵢ` with `wᵢ = Δᵢqᵢ/ΣΔq` · **strike dispersion** `√(Σ wᵢ(kᵢ−K_D)²)`. Magnitude, location, spread. | INVARIANT (Δ is the only axis making option lines commensurable with perps; the weighting is forced — see the asterisk below) / **CHOICE** (labels, precision) | Verified on a sample book (`sims/scripts/strike_duration_check.js`): exposure 15.763 ₿-perp, K_D −2.93%, dispersion 18.13%. **The sensitivity identity holds** — shifting every strike +1% predicts ΔV = −Σ Δ·q · shift = −0.15763 against an actual −0.15585, a 1.13% error that is pure convexity. That is duration behaving as duration. **The asterisk:** in fixed income the PV-weighted average and the first-order sensitivity coincide; here they do not. Value-weighting gives K_D = −2.75% and carries **no** sensitivity identity, so **Δ·q weighting is the one to use** — it is the version where the derivative actually is the number. Reference units already agree: "₿-perp (Δ·q)" (`earnTableContainer.tsx:68–70`). | **operator** entry 589/590 |

| Q16 | How is quote dormancy (entries 606/607) represented to the LP? | **On the LP's own curve**: the stretch of your ask edge below the divider (bid above) renders greyed/hatched, live with bias; the "N% of strikes live" pair is kept as a **summary mirror**, and the prose "sleep — they wake…" line is demoted to a hint. The pricing rule itself is untouched. | RULED (the dormancy rule) / **CHOICE** (this representation) | §4.4 — curve-valued state lives on the curve; scalar summaries mirror, never replace. Cost: locating dormant strikes goes from unrepresented (blind requote loop against a % readout) to 1 glance; steps unchanged. | **ux** (build-39 review, F10) |
| Q17 | Does an end user see the maker-divergence dial (and the realised-vol / turnover / RFQ-size sliders)? | **No — not as trade controls.** All world-state controls move to one collapsed, visually distinct SIMULATION drawer, never inside a commit card; an end-user build omits the drawer. | **CHOICE** | §4.5. The dial currently sits between size and quote in the Order card (`app/index.html:165`) — +1 false glance per trade and mis-touch risk on world state. Sim access +1 step is correct: it is on no commit path. | **ux** (build-39 review, F11) |
| Q18 | Is the depth cloud the right primary trading visual, or does a plain quote need priority? | **Both, by role: the cloud stays** (it is the honest object — entries 559/560/562 — and the continuous-strike control is only valid with the curve co-present), **and the plain number keeps priority at the point of action**: the ticket quote at your size (already present) plus a pointer-hover readout ON the Transact cloud (strike %, $ strike, bid/ask at your size; click sets the ticket strike). Earn's canvas already hovers; Transact's — the one you trade from — must not be the inert one. A 3-word in-chart legend ("brighter = more depth") replaces the essay note. | **CHOICE** | §3 co-presence; entry-557 precedent. Cost: "check price at 5 strikes" ~10 steps (slider/typing) → 1 continuous pointer action, 0 added glances. | **ux** (build-39 review, F12) |
| Q19 | Which research vocabulary survives on the end-user surface? | **Rule: decision-relevant → plain-named; internal → off the surface.** Itemised: parity-check readout → tests; G̃ → dropped (break-even half-spread, its user-facing derivative, stays); "gamma bleed" → "est. hedging cost"; k-axes keep % but hover readouts add $ strikes; build labels and operator-entry citations → footer/docs; multi-line rationale notes → one action line each, rationale to docs. | **CHOICE** | §1/§3 — glances_min counts decision-relevant state only; every non-decision line on a commit screen is a glance tax. | **ux** (build-39 review, F13) |
| Q20 | How does a new user find the whole loop (open → carve → close → payout)? | **One navigation** (single header row; no duplicate in-panel tab bar), an **Open Perp ticket on the Perps tab** (side, size, commit — leverage is account-level, not an input), and **every commit toast carries a back-pointer link** to the resulting position (§4.1's pointer, made a hard rule for all commits). | **CHOICE** (the nav/pointer form) — the loop's *walkability* itself is treated as RULED by entry 607 ("i'd like to try it out") | §4.1, §2. As of build 39 step 1 is inexpressible (`Life.openPerp` has no UI caller): T1 cost ∞ → 3 steps. | **ux** (build-39 review, F14) |

### 5.1 Escalated to the operator — NOT decided here
- ~~**Q5 economics**~~ — **RULED, entry 586.** See §7.
- **Q9 parameter:** the actual quote validity window, once latency is known.

---

## 7. THE CARVE IS A DISPLAY OPERATION (operator entry 586)

> carbed perp is still perp and retains everything perp has

This is a general rule, not one answer, and it retires a whole class of future questions.

**Carving does not create a new economic object.** When an option is written on a perp, the affected
notional is **earmarked and re-listed**, nothing more. The perp continues to:
mark, accrue funding, carry unrealised P&L, contribute to account-level margin and the ~50×
liquidation test, and hold its entry price and size — **exactly as it did before the carve.**

**Consequences that follow without further argument:**
1. **Line 1 is a full perp row.** Same columns as the perps tab, funding included. There is no reduced
   "sliver" row and no special-case formatting.
2. **No new type in the model.** A carved perp is a perp with a binding tag (which option it backs).
   Any code path that branches on "is this a sliver" is a defect.
3. **Anything true of a perp is true of it.** Do not ask the question per property. Funding, mark,
   margin contribution, liquidation weight, P&L — all yes, by this rule.
4. **Only two things change:** which tab it is listed under, and that it is bound to an option (so it
   cannot be closed independently — Q7's compound close).
5. **Total lines are consistent by construction:** perps tab + carved lines = the account's whole perp
   position, always. Any UI that lets those disagree is wrong.

**Test for any future carve question:** would the answer differ for an uncarved perp? If not, the
carve does not change it. That is the whole rule.

### 7.3 What "pro-rata" refers to (operator entry 593)

> i said prorata inthe sense trader may have multiple lps on its position

The pro-rata is the **apportionment of ONE trader position across the several LPs that filled it** —
not a claim on anything. Fills split across all makers by capital share (§0.1(6)), so:

```
one trader bundle  →  N LP accrual rows
Σ (LP fill shares on that position) = 1        exactly
```

**Accounting identity (INVARIANT):** the LP rows' perp-equivalent lines sum to the trader's carved
perp, exactly. Verified on the shipped apportionment: a 30 BTC order splits
`14.29 / 5.71 / 2.86 / 7.14 = 30.00`.

Two things this fixes in my own earlier reasoning:
1. I had guessed the pro-rata pointed at a **pool-level perp in the shared wallet**. It does not. It
   points at **the trader's own carved perp**, divided among the LPs who filled that trader.
2. It is still **not a claim** (§7.2) — an LP's displayed perp line is its share of the trader's carved
   perp for calculation and row consistency, while the LP's accountability remains the option leg only.

**UX consequence — smaller than I first wrote it (operator entry 594):**

> yeah i mean if there multiple LPs sure yes but they're like on different screens / different accounts right

Correct, and it deflates my framing. The 1:N mapping is real **in the ledger** and invisible **on any
screen**: each LP is a separate account, so an LP sees exactly **one** row — its own share — and never
the other LPs' rows. There is no screen anywhere that renders N LP views of one trade, so there is no
"which counterparty" ambiguity to design around, and no disambiguation UI is owed.

What actually survives:
- **The accounting identity is a backend check, not a screen.** `Σ shares = 1` is verified in the
  ledger; no user is shown the sum, because no user can see the parts.
- **The `origin` column earns its place for a different reason** than I gave: not to separate several
  LPs, but to separate *your own two roles* — positions you entered as a trader vs accruals you
  received as an LP — inside **one** account (§4.3).
- It also makes entry 566 obvious rather than a rule to enforce: you cannot see other makers because
  they are **other accounts**, not because a filter hides them.

### 7.2 The trader/LP asymmetry — who owns the perp leg (operator entry 592)

> a when lp is seller hes really accountable to the bundled net perp options / v spread p/l not the
> perp p/l — so perp unit / line is just for calculation / math / ux consistency i guess

| | trader | LP |
|---|---|---|
| owns the carved perp? | **yes** — it is their perp, carved | **no** |
| perp leg enters payout? | **yes** | **NO** |
| accountable for | option leg **+** carved perp leg | **the bundled net option / spread P&L only** |
| what line 1 is | a real position | a **perp-equivalent display and calculation line** |

**Worked, on the same trade** (`sims/scripts/units_to_payout_chain.js`): a 3 BTC +12% call, spot +8%.
The trader nets `−$6,120 (option) + $15,767 (perp) = +$9,647`. The LP on the other side nets the
**option leg alone, +$6,120** — the $15,767 never touches it. Same trade, two different payout
compositions, and the row looks the same in both because the perp line is there for consistency.

**Tier:** the accountability is **INVARIANT**. The presence of the line is a **CHOICE**, and the reason
to keep it is that it preserves one row shape and keeps every line in Δ·q perp-equivalents so the Earn
duration triple (§5 Q15) sums over a single currency.

**INVALID surfaces this rules out:** any LP view that adds a perp P&L into the LP's payout, and any LP
close that appears to close a perp. It does neither.

### 7.1 The bundle is the unit (operator entry 587)
> no option can be sold without a perp its carved from
> all perp options or vertical spreads opened bundle at once full closed together w slover perp

Two invariants that together define the traded object:
1. **No naked option.** Every option is carved from a perp. The perp line therefore always exists —
   that is why the row count has a floor of 2 (perp + one option leg), not 1.
2. **The bundle is atomic.** An option or vertical spread and its sliver perp **open together and
   close together, in full.** There is no partial close and no independent close of either part.

Consequences: the carve record is **immutable** — created whole, destroyed whole; a close ticket has no
size control, only a confirm; and Q7's "compound close" is not a convenience, it is **the only close
that exists.**

## 6. Standing obligations
1. Every proposal reports **steps and glances** against §2, with the counting shown.
2. Every placement cites the **§4 cell** it followed.
3. Every removal of a step or glance states why §3 is not violated.
4. Every new quantity introduced by a **core** change is classified here before it reaches a screen.
5. Anything that is really an economics question is **escalated**, not silently picked.
