# TEMPORAL — CORE SPINOFF (2026-08-15, operator entry 629)
Everything of validated value, separable from the repo.

engines/    book.js (dormancy-divider RFQ book: aggregate=divider, quotes stand, crossers dormant;
            never crossed, both sides always alive, mark/close self-excluded) · lifecycle.js
            (perps, carve, ATOMIC bundles, account-level 50x, LP-excluded, ledger; 38 checks) ·
            paper.js (closed-network wallet, conservation-checked) + adversarial suites. All node-runnable.
maths/      burr2_kernel.js (the pricing kernel, verbatim) · the operator's swap-pricer sheet ·
            BURR2_FULL_LOOP_v1.xlsx (whole loop, 10 sheets) · LP_EXPOSURE_CURVE_v2.xlsx (limits-only LP).
formal/     v3-maps-lean (54 thms, locally kernel-checked) + Aristotle runs + provenance INDEX.
decisions/  UX_FORMALISM (tiers INVARIANT/RULED/CHOICE, taxonomy, Q1-Q20) · RULINGS_REGISTER ·
            OPERATOR_INTERFACE_CONTRACT · closed-loop map · RFQ/mixture note (skeptic verdicts inline) ·
            lifecycle + interaction-cost docs · CLAUDE.md.
record/     history/ — the COMPLETE verbatim operator transcript, entries 1-629. The critical asset.
engine_head/ the v28 engine HEAD html + lineage + diff ledger (the locked product line).
measurements/ every verification script written this line of work (dormancy, divider, convexity,
            strike-duration, units-to-payout, natural-map, arb-grid, conservation...).

The reference frontend (perp-frontend-hyperliquid-staging) lives in gnostrich/Perp-Options-OB-MM —
it BUILDS clean with NEXT_PUBLIC_EXECUTION_MODE=paper (9 routes, verified 2026-08-15) and is the
intended UX shell for these engines.
