# Run-context for these 28 scripts (read before running anything)

These scripts are the MEASUREMENT EVIDENCE behind the numbers quoted in `rfq_decisions/` —
they were executed inside the original repo, and their file paths point at repo files that are
deliberately NOT in this archive (the retired frontend console and its module files):

- 24 scripts extract the Burr-2 kernel from `app/index.html`'s `<script>` block
  (`fs.readFileSync('app/index.html')`, stubbed-DOM `vm` context, then use `mk(...)` only).
- `lifecycle_check.js`, `lifecycle_adversarial_check.js`, `lp_asymmetry_check.js` load
  `app/lifecycle.js`; `paper_wallet_check.js` requires `../../app/paper.js`;
  `book_model_check.js` / `book_adversarial_check.js` load `app/book.js` + the console kernel.

Nothing MATHEMATICAL is missing from this archive:
- the kernel the 24 scripts extract is `kernel_and_sheets/burr2_kernel.js` (same `mk`);
- `app/book.js`, `app/lifecycle.js`, `app/paper.js` are here as `engines/book.js`,
  `engines/lifecycle.js`, `engines/paper.js`.

To re-run a script standalone: replace its kernel-extraction preamble with
`require('../kernel_and_sheets/burr2_kernel.js')` (or `vm`-run that file) and point
`app/<x>.js` paths at `../engines/<x>.js`. The scripts have NOT been rewritten here —
they are preserved byte-for-byte as the evidence that was actually executed.
