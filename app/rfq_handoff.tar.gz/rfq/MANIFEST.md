# RFQ HANDOFF — mechanism only (operator entry 633)
NO frontend material of any kind, no UI docs, no HTML builds, no older FE versions.

engines/            book.js — the dormancy-divider RFQ book (make(makers) → mid/ask/bid/landed/
                    apportion/mark/closePx; self-exclusion; never crossed; both sides always alive)
                    lifecycle.js — carve/bundle/account store (atomic bundles, 50× account-level,
                    LP-excluded, ledger; canClosePerp gate)
                    paper.js — closed-network paper money (conservation-invariant ledger)
                    + their full check + adversarial suites (node <file>).
kernel_and_sheets/  burr2_kernel.js (verbatim pricing kernel) · the operator's swap pricer ·
                    BURR2_FULL_LOOP_v1 (+notes) · LP_EXPOSURE_CURVE_v2 (limits-only LP).
lean/               v3-maps-lean (54 theorems, locally kernel-checked) · aristotle_runs · INDEX.
rfq_decisions/      RFQ_MECHANISM_RULINGS.md (the mechanism, 10 points, entry-cited) ·
                    CLOSED_LOOP_MAP · RFQ_ENVELOPE_vs_MIXTURE (skeptic verdicts inline).
rfq_measurements/   28 mechanism scripts: dormancy/divider/overlap variants, convexity, bias budget
                    & density, healing axes, inventory skew, strike duration, units→payout, natural
                    map + ceiling, sheet exact-match, basis reconcile, parity-same-dollar, etc.
record/             the complete verbatim operator transcript (entries 1–633).
