# RFQ HANDOFF — mechanism only (operator entry 633; purity re-audit entry 637)
NO frontend material of any kind, no UI docs, no HTML builds, no older versions.
This manifest lists EXACTLY what is in the archive — nothing listed here is absent, nothing
present is unlisted.

engines/            book.js — the dormancy-divider RFQ book (make(makers) → mid/ask/bid/landed/
                    apportion/mark/closePx; self-exclusion; never crossed; both sides always alive)
                    lifecycle.js — carve/bundle/account store (atomic bundles, account-level margin,
                    LP-excluded payout, ledger; canClosePerp gate)
                    paper.js — closed-network paper money (conservation-invariant ledger)

kernel_and_sheets/  burr2_kernel.js — the Burr-2 pricing kernel, standalone (mk(Sbar,a,gam,kap) →
                    CALL/PUT/ATM; parity C−P=−k exact)
                    temporal_burr2_swap_pricer_6.xlsx — the operator's original pricer sheet
                    BURR2_PRICER_AUDIT.md — audit of that sheet vs the kernel
                    BURR2_ECONOMICS_AND_AGGREGATION.md — aggregation economics note
                    BURR2_FULL_LOOP_v2_RFQ.xlsx — the complete loop, CURRENT (RFQ rules sheet,
                    live dormancy-divider sheet with MINIFS/MAXIFS + PASS checks, limits-only LP)
                    LP_EXPOSURE_CURVE_v2.xlsx — limits-only LP curve (E+/E− → N_bid/N_ask/tilt)

lean/aristotle_runs/  BURR2_CORE and BURR2_MIXTURE ONLY — the two Burr-2 obligations (submitted
                    text, returned proofs, prover-reported axioms, local build logs, submission
                    ids). No other formal work is included.

rfq_decisions/      RFQ_MECHANISM_RULINGS.md — the mechanism, 10 points, each operator-entry-cited
                    RFQ_ENVELOPE_vs_MIXTURE_2026-08-14.md — envelope-vs-mixture analysis with the
                    skeptic's adversarial verdict inline (unedited)
                    PAYOUT_DERIVATION_NOTES.md — units → dollar payout derivation

rfq_measurements/   28 mechanism scripts: dormancy/divider/overlap variants, convexity, bias budget
                    & density, healing axes, inventory skew, strike duration, units→payout, natural
                    map + ceiling, sheet exact-match, basis reconcile, parity-same-dollar, LP
                    asymmetry, lifecycle + paper-wallet + adversarial suites.
                    ⚠ RUN-CONTEXT: these were executed in the ORIGINAL repo and load their pricing
                    functions from repo paths (`app/index.html` console <script>, `app/*.js`) that
                    are NOT in this archive — see rfq_measurements/RUNNING.md. The mathematics they
                    need is fully present (`kernel_and_sheets/burr2_kernel.js`, `engines/*.js`);
                    only the file paths point outside. Their measured results are recorded in the
                    rfq_decisions/ docs. They are evidence, not a ready-to-run harness.

record/operator/    2026-06-10_kurtosis-curve-family-brief.md — the complete verbatim operator
                    transcript of the session (entries 1→636). Kept as ruling provenance: every
                    entry number cited in rfq_decisions/ resolves here. ⚠ Being a full transcript,
                    it necessarily contains the operator's discussion of the retired frontend and
                    earlier engine lines alongside the RFQ rulings. It is the operator's own words,
                    verbatim, per standing transcription policy — not imported material.

## Honesty notes (what "RFQ-only" does and does not mean here)
- Several analysis docs (BURR2_PRICER_AUDIT, RFQ_ENVELOPE_vs_MIXTURE, PAYOUT_DERIVATION_NOTES,
  the Lean obligation comments) mention the retired lens/v28 engine line BY NAME — always to
  define the Burr-2/RFQ design AGAINST it or to scope a theorem. No retired-line artifact
  (code, build, proof archive) is included.
- The removed items from earlier cuts stay removed: no v3-maps-lean (OB line), no GH/lens-era
  Aristotle runs, no INDEX.md, no CLOSED_LOOP_MAP, no FULL_LOOP v1 or its notes, no FE files.
