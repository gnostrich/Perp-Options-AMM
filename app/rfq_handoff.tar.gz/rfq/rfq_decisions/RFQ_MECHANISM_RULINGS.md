# THE RFQ MECHANISM — operator rulings, mechanism only (entries cited; verbatim source in record/)
1. RFQ, not orderbook (554/568/577): makers quote whole curves and differ freely; no shared resting
   book; buying = matching the best quote across makers; fills split at each maker's own price.
2. Visibility (566): a participant sees SELF and the AGGREGATE only — never another maker.
3. THE PRICING RULE — dormancy divider (580 → 603 → 606/607, final): aggregate ALL curves into ONE
   spread-free curve (capital-weighted mids). That aggregate is the DIVIDER. Each LP's own bid and
   ask curves stand as posted. Any quote crossing the divider is DORMANT — never matched, never
   clipped; it wakes when the divider moves or the maker requotes.
   Proven/measured: never crossed at any divergence; NEITHER side can empty (divider is a weighted
   mean ⇒ max ≥ mean ≥ min); every fill at a real maker's own posted price; spread emerges naturally
   and widens with disagreement.
4. Quoting (571/572): level solved from oracle vol via the natural map (premium ∝ vol, invertible;
   ceiling at ATM supremum 0.5586 ⇒ ~RV 186% with a,γ fixed); per-LP BIAS tilts it; or full manual.
   Bias is a SIDE/DENSITY selector (575): lean cheap ⇒ you are the seller across strikes; lean rich
   ⇒ the buyer.
5. LP inputs (604/607): exposure limits E+/E− ONLY — no notional, no leverage input. The curve
   interpolates with current exposure: N_bid = max(0,E+−e), N_ask = max(0,e−E−); level tilt
   −t_max·(e−mid)/half-range. Margin is venue accounting, not an LP choice.
6. Healing axes (573/574, measured): trades move κ ⇒ κ-disagreement self-heals (16 rounds, $382);
   level heals via the ORACLE (+ inventory tilt); SHAPE (a,γ) heals via NOTHING ⇒ shape must be
   common. Whole-curve-moves-together is what bounds the per-strike replication leak.
7. Carve model (583/586/587/615): no naked option — every option carved from a perp; the bundle
   (option/spread + carved perp) opens at once and CLOSES IN FULL together; a carved perp is still a
   perp in every respect (funding, mark, margin, liquidation weight) — display re-listing only;
   ≤5 portfolio lines, exactly 1 = the carved perp.
8. Trader/LP asymmetry (592/593/594): trader payout = option leg + carved perp leg; an LP is
   accountable to the option leg ONLY — its perp line is calculation/consistency, not a claim.
   Pro-rata = one trader position apportioned across the N LPs that filled it (ledger fact; each LP
   is a separate account and sees only its own share).
9. Settlement (578/592): payouts realised via BUY/SELL, not intrinsic; a close is a trade at the
   AGGREGATE with the closer's own curve EXCLUDED (self-exclusion also governs marks); leverage does
   NOT scale the payout (the old ×L₀ was wrong); account-level liquidation, perps+options one pot,
   ~50× cap, LP excluded; no per-position liquidation price exists.
10. Parity (576/577): C−P=−k holds exactly per maker; book-level residual ≡ the crossed edge
    (one phenomenon, two counts) — moot under the divider.
