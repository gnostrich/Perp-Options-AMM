# Temporal MVP — Session Context / TBD Tree

> Live brainstorm note. Branching tree, expanded not compacted.
> Mode: BRAINSTORM ONLY. No edits to v5 HTML until Rohan says "do a pass."
> Working file: temporal_mvp_composite_ray_v5.html (v5.1 shipped)

---

## 0. Session frame

- **Purpose of the MVP**: CTO handoff reference. The spec by which the CTO
  upgrades the live DEX:
  - rip out old RB-tree numerical/approximation AMM
  - drop in the closed-form composite-ray engine
  - small corrective changes to settlement logic
- **Implication**: engine + trading-mechanics fidelity is what matters.
  Portfolio/LP polish is cosmetic by comparison.
- **Mode**: brainstorm; Rohan feeds findings; Claude maintains this note;
  passes happen only on explicit instruction.

- **Sequencing principle (Rohan)**: get trade mechanics crystal-clear
  FIRST. Once the engine is right, portfolio falls into line easily —
  it's downstream of correct mechanics. F3/F4/screenshot items are
  "setting the stage" — captured now, not actioned. Rohan hasn't yet
  reached portfolio-update / value-correctness simulation.
  => Portfolio Qs (Q2-Q7) parked, not blocking. Focus stays on 2.1/2.2.

  - RESOLVED Q17: Fork A & Fork B produce the SAME payoffs (same economic
    object, different implementations). F6 is NOT "corrected vs current"
    — there is ONE correct payoff. Composed curve = barrier-correct
    payoff (entry-spot threshold, equity base). Forks differ in how the
    backend computes it, not what it is.
  - RESOLVED Q18: continuous, area-chart style.
  - RESOLVED Q21: bare comparison perp held at SAME MARGIN, different
    leverage — capital-efficiency comparison (gains on same capital,
    liquidation-floor / risk made visible).
  - D1 RESOLVED: composed-payoff logic written FROM SCRATCH in graph
    code. Works in CARVED-PORTION PERP EQUITY (not margin). Piecewise
    barrier: perp linear P&L on carved equity, minus sold-leg payoff
    above its entry-spot threshold, plus bought-leg protection below its
    threshold, capped at outers. New logic, exists nowhere else.
  - D2 RESOLVED: F6 reads from Transact panel for the composed band
    (simplest UX, iterate if fragile). Input sources:
    - baseline perp (leverage, entry mark, notional/carved-equity) —
      ALREADY GIVEN, taken from the perp portfolio. F6 does not ask.
    - the band (sold+bought legs, bounds) — from the Transact panel.
    - F6's ONE OWN input: comparison perp's leverage (single scratch
      control). Comparison perp at same margin as baseline, diff lev.
  - Empty state: if no perp / no band configured, F6 shows neutral
    "configure a position to preview" — no error, no garbage plot.

  #### >>> F6 PAYOFF MECHANIC — LOCKED (revised after deep brainstorm)
  - Positions move around on the ANCHOR curve (w=1/2, fixed shape).
    Live pool curve would need arb-into-shape per price step — not
    automated (production-adjacent) — so anchor is the deterministic ref.
  - 45-degree point of the anchor = ATM = current spot oracle. When
    oracle moves, the 45-deg point re-anchors to the new spot; everything
    else reads proportionally off it.
  - A leg has a fixed strike -> fixed point/slope on the anchor. As spot
    sweeps, the leg's moneyness re-reads. mark = min(slope, 1/slope) is
    the FRACTION (in (0,1]) the leg is worth, of a full perp.
  - **Leg value = fraction x carved-perp EQUITY** (equity = margin + P&L,
    NOT notional/margin alone — same principle as the settlement patch /
    Q13). A band is a live fraction of a perp.
  - Composed position = perp equity - sold-leg value + bought-leg value.
  - Implementation: equals Engine.mark(wing, theta, sNorm) with theta
    fixed (= K / entry-oracle) and sNorm = S_swept / S_entry. The engine
    mark function already encodes min-slope-or-reciprocal vs the ATM
    point — feed it the swept sNorm.
  - NOTIONAL ASYMMETRY (the crux): N_sell small, N_buy large. N_buy is
    ENGINE-DERIVED via cash-conservation V_buy = V_sell, using the real
    Engine.legPrice (Q24 = a-i). Sell little upside, buy lots of floor.
  - THREE liquidation LINES (vertical markers, not curves):
    i. comparison perp (bare, cmpLev) — TOGGLEABLE
    ii. unmodified perp (bare, baseline leverage) — always shown
    iii. protected perp (composed) — always shown
  - Comparison perp toggle answers: "is this just the same as running
    lower leverage?"
  - **SHORTCUT vs SEPARATE ACCOUNTING (principle)**: the composite-ray
    shortcut (theta*=sqrt(ti*to), 2sinh(delta) form) is an EXECUTION
    convenience — opens/closes a spread as ONE AMM swap instead of two.
    It does not hold in the OTM regime. So for VALUING / TRACKING a
    position as price moves, do NOT use the shortcut — account the two
    barriers SEPARATELY (inner barrier minus outer barrier). Honest, and
    simpler (sidesteps where the shortcut breaks).
    => shortcut = how you TRANSACT; separate barriers = how you VALUE.
    => F6 payoff curve: spread leg value = N*(mark_inner - mark_outer),
       each re-marked at swept sNorm, * carved equity.
    => 2sinh(delta) stays ONLY in the N_buy premium derivation (a
       transaction-time quantity), never in the payoff curve.
  - **TENT SHAPE — ACCEPTED (design, not a bug)**: these are BARRIER
    instruments, not American options. A bought spread = long inner
    barrier - short outer barrier. Each barrier's value = mark capped at
    1 (tops out at ONE unit of carved perp when ITM, stays at 1 deeper
    ITM). Netting the two barriers gives a TENT: protection value peaks
    inside the band, decays toward 0 past the outer bound. You cannot get
    "saturate and stay" from a finite barrier spread.
    => Trade-off the protocol accepts: buy THICKER spreads — a wide band
       so the tent stays tall across the region where liquidation
       threatens. Thin spread = tall narrow tent = sliver of protection;
       thick spread = broad tent = real floor coverage.
    => This explains the earlier "narrow band, many units, floor barely
       moves" smoke-test: not a bug — the model honestly showing a narrow
       spread is a poor liquidation hedge.
  - **F6 PAYOFF MODEL — FINAL**: every barrier value = min(mark,1) * N *
    carvedEquity, re-marked at swept sNorm. A leg = 1 barrier (barrier)
    or 2 barriers netted (spread = long inner - short outer). Composed
    equity = perp equity - sold-leg value + bought-leg value. No
    2sinh(delta) in the payoff. Tent shape is expected output.
  - **STRUCTURAL FINDING — costless-collar arb is a SKEW phenomenon**
    (surfaced from F6 smoke-tests; instrument-agnostic).
    - Costless collar: V_sell = V_buy by construction. Bought-leg total
      value is pinned to the V_sell budget.
    - Symmetric pool (w = 1/2, no skew): marks symmetric across wings.
      Premium raised = premium spent, priced off the SAME symmetric
      curve. No capital-efficiency edge — what you give up equals what
      you get. "Sell little, buy lots" does NOT hold at zero skew.
    - The edge requires the BOUGHT wing cheaper per unit than the SOLD
      wing — that asymmetry IS skew (w != 1/2). Skewed pool depresses one
      wing's mark; if the protection wing is the cheap one, the V_sell
      budget buys more units there. Directional: exists when consensus is
      crowded on the side you sell, leaving protection underpriced.
    - Holds for barrier AND American — falls out of V_sell=V_buy + the
      pricing symmetry, not from the instrument choice.
    - Connects to funding: protocol funding is countercyclical (taxes
      skew, pays contrarian). Collar edge and funding flow are the SAME
      quantity — directional imbalance — seen twice. No skew => no edge
      => no funding flow. Coherent.
    - CAVEAT (do not overclaim): "no arb without skew" is about CASH /
      pricing arbitrage. Liquidation protection still has RISK-MANAGEMENT
      value at zero skew — the perp is leveraged, liquidation is
      discontinuous & ruinous; capping smooth upside vs preventing a
      wipeout are not symmetric in UTILITY. At zero skew the collar can
      still be worth doing; what vanishes is the FREE value.
    - TODO: re-run F6 with a deliberately skewed pool (w != 1/2) — N_buy
      should jump, floor should move. Confirms the thesis vs merely being
      consistent with it.

## 1b. BUILD SCOPE — pass authorised by Rohan (this pass ONLY)
- THREE edits this pass, nothing else:
  1. F6 — fourth graph, interactive payoff simulator
  2. F2 — outer-bound box sized to match inner-bound box
  3. F1 — dollar subline = per-leg dollar notional on BOTH legs
     (range-invariant); virtual-dollar / premium-flow -> audit section
- Everything else (F3 F4 F5, fork patches, auto-protect, polish bucket)
  stays PARKED for the next pass.

## 1. Priority spine (this session)

1. [ ] Visual formatting — curve viz / trading surface reads correctly
2. [ ] Trading mechanics — engine fidelity (barrier/spread, cross-wing,
       OTM, premium math)
3. [ ] Portfolio / settlements — existing-position info (lower priority)
4. [ ] LP — last; may not do at all

---

## 2. TBD tree (grows from Rohan's findings)

### 2.1 Visual formatting
- [ ] **F6 — FOURTH GRAPH: interactive payoff simulator** *** PRIORITY ***
  - Promoted ahead of the fork items for immediate push.
  - PURPOSE: pre-trade payoff simulator — trader sees WHAT THEY'RE
    ENTERING before committing. New 4th graph on the graph panel.
  - Compares TWO curves over a perp-mark % change x-axis:
    - Curve 1 — COMPOSED position: perp + the band being configured
      (sold leg + bought leg). The protected payoff profile.
    - Curve 2 — BARE perp, with its OWN selectable leverage, as the
      comparison baseline.
  - Plus LIQUIDATION-FLOOR COMPARISON: where the composed position
    liquidates vs where the bare perp liquidates. Derisking made visual.
  - RESOLVED Q16: TWO curves (composed vs one bare perp), not three.
    Bare perp's leverage is an independent comparison control. Image's
    3-way (3x/5x/protected) was just illustrative.
  - RESOLVED Q19: y-axis = position equity / payoff in $ ("what you're
    entering" => equity is the trader-relevant quantity).
  - RESOLVED Q20: composed curve reads the band CURRENTLY being
    configured in the Transact panel (pre-trade tool must reflect live
    trade inputs). Bare-perp leverage = separate scratch control.
  - OPEN Q17 [KEY]: composed curve uses CORRECTED Fork-A barrier
    valuation (entry-spot threshold, equity-based bought-leg value) or
    current model? Pre-trade "what you're entering" => should show TRUE
    payoff => corrected semantics. Means F6 is built on corrected math
    BEFORE backend patch ships (F6 becomes visual proof of the corrected
    model). Confirm — this couples F6 to the fork work.
  - OPEN Q18: x-axis — continuous line vs stepped bars. Sweep range
    (+/-50%) fixed or a control?
  - OPEN Q21: bare-perp comparison curve — same notional & same entry
    mark as the composed position, only leverage differs (apples-to-
    apples)? Assume yes — confirm.

- [ ] **F1 — dollar subline semantics** (also touches mechanics/display contract)
  - Problem: $ subline under BTC quantity means different things per leg
    - Sell leg: dollar notional (N_sell * oracle)
    - Buy leg: virtual dollar proceeds (V_sell premium recycled to size buy)
  - Fix: BOTH legs show **dollar notional** in the subline
    - Sell leg: N_sell * oracle
    - Buy leg: N_buy * oracle  (N_buy is the derived cash-conserving qty)
  - **Notional is per-leg and RANGE-INVARIANT**: subline = N_leg * oracle,
    unchanged when inner/outer bounds (barrier/spread range) are adjusted.
    Bounds reshape premium & curve position; notional is a fixed leg property.
  - Virtual-dollar / premium-flow figure -> moves to **audit section**
    (this IS the range-sensitive number; belongs in audit, not primary card)
  - Q1 RESOLVED: each leg shows its OWN notional (N_buy*oracle on buy leg).
- [ ] **F2 — outer-bound box sizing**
  - Outer-bound input box should match inner-bound box size
  - Goal: symmetric / aesthetically clean; up-down stepper arrows
    comfortably visible & clickable
  - Current: outer box sized differently (likely smaller)

### 2.2 Trading mechanics
- (none yet — F1 has a display/mechanics overlap, tracked under 2.1)

### 2.3 Portfolio / settlements
- [ ] **F3 — portfolio combined Total column**
  - Problem: portfolio shows Value + Funding as separate columns;
    user must mental-math the all-in number
  - Fix: add a 3rd column **Total** (= Value + Funding), signed sum
  - Funding carries sign (sold legs opposite-sign to bought legs;
    crowded side pays / contrarian receives) -> Total can be above OR
    below Value. Straight signed sum, NOT Value + |Funding|.
  - Display contract: BTC-primary, $ secondary (match Value/Funding cols)
  - OPEN Q2: column label — "Total" vs "Position Value"?
  - NOTE: F3's Total column likely subsumed by F4's Total row — see F4.

- [ ] **F4 — per-leg-piece portfolio breakdown** (big restructure)
  - Current: one row per band (collapsed band value)
  - Proposed: each band expands into UP TO 4 lines
    - Sold part: 1-2 pieces
    - Bought part: 1-2 pieces
    - 1 piece = barrier (inner bound only); 2 pieces = spread (inner+outer)
    - band = sold(1-2) + bought(1-2) => 2 to 4 lines
    - + a **Total row** at end of band
  - Purpose: see VALUE BREAKUP per piece, not just collapsed band value
  - Per piece, retain TWO strikes:
    - Original strike — strike as opened
    - Effective strike — = original while OTM; snaps to spot when ITM,
      tracks spot thereafter. Closure-relevant.
  - At closure: per-piece rows are DISPLAY/BREAKDOWN ONLY.
    Execution still uses composite-ray shortcut — club pieces, run sell
    transaction in ONE SHOT. Breakdown informs; shortcut executes.
  - OPEN Q3: "strike" granularity for a spread piece — composite theta*
    (one number), or inner/outer bounds pair?
  - OPEN Q4: ITM definition for effective-strike snap on a spread —
    snap at inner-bound crossing? effective strike = clamp(spot, bounds)?
  - OPEN Q5: does the 4-line breakdown REPLACE the band row outright,
    or does a collapsed band row remain and expand into the breakdown?
  - **Old portfolio (screenshot, to be replaced)** — header was:
    SELL | NOTIONAL (BTC) | DIRECTION | INTRINSIC VALUE | FUNDING |
    EXTRINSIC VALUE | POSITION VALUE | INITIAL INNER BOUND |
    INITIAL OUTER BOUND | RESIDUAL INNER BOUND | RESIDUAL OUTER BOUND | CLOSE
  - Why old layout failed (Rohan): "hid and aggregated away information",
    hectic to work with. Resolving to make it crystal clear as part of the
    closed-form upgrade.
    - one row per band -> sold+bought collapsed, no per-piece value breakup
    - "INITIAL/RESIDUAL inner/outer bound" = old cumbersome vocab for
      F4's original strike / effective strike. "Residual bound" -> rename
      to "effective strike". 4 bound columns flatten a per-piece pair.
    - INTRINSIC/EXTRINSIC/POSITION VALUE split by type but not by piece
  - => F4 is a COLUMN rethink too, not just adding rows. New per-piece row
    carries: piece identity (sold/bought, barrier/spread), original strike,
    effective strike, value contribution. Band Total row aggregates.
  - OPEN Q6: keep intrinsic/extrinsic value split per piece row, or is it
    redundant? (effective != original gap already encodes intrinsic)
  - OPEN Q7: CLOSE action stays at BAND level (one-shot composite-ray on
    whole band), not per piece — confirm.
- [ ] **F5 — origin-perp accounting columns in bands portfolio**
  - Each band is opened against an ORIGIN PERP (the perp futures
    position the band protects). Settlement is denominated in units of
    this perp (L0 frozen at open, trader_payout = L0 * raw_net, perp-club
    equity bucket) -> perp accounting must be carried with the band.
  - Add 4 perp-side columns:
    1. Perp equity at entry — origin perp equity at band-open
    2. Perp mark price at entry — perp mark at band-open
    3. Attributable perp P&L since — perp P&L since entry, attributable
       to this band
    4. Perp equity at closure — origin perp equity at close time
  - Placement: all 4 sit on the row for the **inner bound of the sold
    part** (sold leg's primary piece row). NOT repeated across other
    piece rows — band-origin properties anchored to one row.
  - Rationale: sold-part inner-bound row = natural band "anchor row"
    (primary piece of the leg whose premium funds the band).
  - OPEN Q8 RESOLVED: perp side runs an AGGREGATION MODEL — trader's
    perp is a single aggregated position, grows/shrinks as same-direction
    size is added (not discrete lots). A band is created FROM A PORTION
    of that aggregated perp.
    => F5's 4 columns = stats of the CARVED PORTION the band was minted
       against, frozen at band-open. Accounted separately so the band's
       settlement math is not contaminated by post-open perp activity
       (more size added, mark moved, equity changed unrelated to band).
    => Perp-side analogue of frozen-attribution: L0 frozen at open, AND
       the carved portion's entry stats (equity, mark) frozen at open.
       Band carries its own immutable origin slice.
    => "Attributable perp P&L since" = P&L of that frozen slice tracked
       forward, NOT a re-derived share of the live aggregate.
  - OPEN Q11 RESOLVED: carved slice is frozen in ABSOLUTE NOTIONAL.
    Later same-direction perp adds do NOT dilute it. Attributable P&L
    since = mark-move * fixed slice notional. The slice also records its
    own carved underlying EQUITY at open (the band's frozen origin slice
    = {absolute notional, entry equity, entry mark}, all immutable).
  - OPEN Q9: closure-time fields (perp equity at closure) render blank/
    em-dash for an open band, fill on close — confirm (no live estimate).
  - OPEN Q10: relevance class — these are CLOSURE-relevant specifically,
    a possible 3rd bucket distinct from trade-relevant / audit-relevant.

### 2.4 LP
- (deferred / maybe not)

---

## 3. Carry-over from mvp_v5_brainstorm.md (not yet triaged this session)

### Polish bucket (small, fast)
- [ ] Per-field red border on OTM violation (engine already rejects)
- [ ] Per-leg signed slippage in audit strip (band-level absolute in summary)
- [ ] Audit-strip label adapts to mode (barrier: V=N*mark; spread: V=N*mark*2sinh)
- [ ] Stale summary tooltip ("0 in current closed-form simulator")

### v6 deferred (LP / Earn) — out of session priority unless promoted
- LP deposits/withdrawals with leverage L
- Two-curve uniform scaling on deposit (1+s, s = D*L/V_total)
- Synthetic vs borrowed leverage semantics
- Perp-style LP liquidation rule
- LP P&L decomposition
- LP withdrawal of accrued fees
- Funding on leveraged LP portion

---

## 4. Closed decisions (don't reopen)

- Fee: open-only, 0.0001 * N_input, separate counter (not pool inflow)
- Slippage: display-only, closed-form already prices it
- No sliders; stepper sensitivity solves sim-sweep
- Same-wing 4-strike model from v4 dropped; cross-wing canonical
- Audit strip default collapsed
- Barrier = trade primitive; spread translates through it
- BTC-primary display, $ inline secondary
- Strikes stay in $

---

## 2.5 SETTLEMENT FORK — minimal-change vs full rework

> Surfaced from the perp-backend repo + old portfolio screenshot.
> Two distinct paths for getting intrinsic value correct. Keep as a fork
> until Rohan decides where to take it.

### Backend grounding (perp-backend-main)
- Settlement math lives in `settlements/services/residual_bonds.go`:
  `CalculateSoldResidualBond(perpMark, boundLow, boundHigh)` and the
  Bought mirror. Clean piecewise:
    - perpMark <= innerBound -> profit 0, range untouched
    - perpMark >= outerBound -> profit = outerBound - innerBound (traversed)
    - inside           -> profit = perpMark - innerBound (partial)
- "Intrinsic value" (frontend label) = `profit`, measured FROM innerBound.
- Callers: `update_transaction.go` L78-82 pass tx.SoldInitialInnerPrice /
  tx.BoughtInitialInnerPrice as the bounds. These fields currently hold
  the STRIKE.
- Transaction model (`settlements/models/transaction.go`): has
  SoldInitialInner/OuterPrice + Bound, Bought mirror. NO entry-spot field
  currently exists.

### Diagnosis (Rohan)
- Current model tracks **spot vs strike**.
- A barrier option's intrinsic should track **spot vs entry-spot**
  (entry-spot = the barrier reference, not the strike).
- residual_bonds.go ALREADY measures profit from innerBound — the bug is
  only WHAT is fed as innerBound (strike, should be entry-spot).

### Fork A — minimal change (rip-and-replace into EXISTING settlement)
- residual_bonds.go itself needs NO change — it's parametric in the bounds.
- Change is one level up: what populates the inner bound.
  - A1: repopulate SoldInitialInnerPrice with entry-spot at open.
    Zero settlement-code change; but loses strike from that field, and
    frontend INITIAL INNER BOUND column then shows entry-spot.
  - A2: add SoldEntrySpot/BoughtEntrySpot fields to Transaction model,
    populate at open, change update_transaction.go callers (L78-82) to
    pass entry-spot as inner-bound arg. Strike stays for display.
    Cost: 1 new field + 4 edited call-sites. Honest version.
- **CATCH**: profit when traversed = outerBound - innerBound. Shifting
  inner ref to entry-spot WITHOUT rebasing outer changes max-payoff width
  (outer - entrySpot != outer - strike). => must rebase the WHOLE bound
  PAIR onto the entry-spot frame, not just inner. Still cheap, 2 numbers.
- Value: buys correct barrier intrinsic NOW, before the closed-form AMM
  swap. A bridge for the current RB-tree product.

#### >>> FORK A — LOCKED PATCH (supersedes A1/A2/CATCH above)
- Key discovery: `tx.PerpMarketPrice` ALREADY EXISTS on the Transaction
  model and is ALREADY populated at band-open (transact/insert_into_DB.go
  L126). It IS the entry-spot. NO new field, NO schema change needed.
- The "CATCH" (width) dissolves under A-anchor: leave the outer bound as
  the trader's CHOSEN outer strike. Collar runs entry-spot -> outer
  strike. Max payoff = outerStrike - entrySpot — the honest number.
  No `width` computation, no pair-shift.
- **THE PATCH**: update_transaction.go L78-82, four call-sites
  (sold/bought x long/short). Swap ONE argument:
    inner-bound arg: tx.SoldInitialInnerPrice (strike)
                  -> tx.PerpMarketPrice (entry-spot)
  outer-bound arg unchanged. residual_bonds.go regime block UNTOUCHED.
  Transaction model UNTOUCHED.
- Verify before ship:
  - PerpMarketPrice is perp MARK frame (matches updatedPerpPrice fed to
    residual_bonds), not an oracle index. (Q12 resolved into this.)
  - residualInner output in untouched regime now returns entrySpot not
    strike -> changes frontend RESIDUAL INNER BOUND display only.

#### >>> RESIDUAL-VALUE DENOMINATION PATCH (second surgical patch)
- Premise (Rohan): a band's value IS a knock-thresholded perp payoff.
  An OTM band = a FRACTION of a perp. => the multiplier is the thing
  being fractionalised: fraction x (one perp).
- "One perp" worth = its EQUITY (margin + accrued P&L), not entry margin.
  A band is a LIVE claim (funding accrues, intrinsic tracks live spot via
  Fork A, closes at live price). Every other limb is live -> the base
  must be live too. Frozen entry-spot THRESHOLD + live EQUITY base is the
  coherent pair. Frozen threshold + frozen margin = double-freeze (wrong).
- Correction to earlier reasoning: Fork A anchors the THRESHOLD (reference
  line) to entry-spot; it does NOT freeze the PAYOFF. Payoff
  (perpMark - entrySpot) is live. So consistent partner = live base.
- WHICH equity: the CARVED PORTION's equity, NOT whole-perp equity.
  Whole-perp equity would inject unrelated perp activity (contamination,
  violates frozen-origin-slice principle). Carved-slice equity = carved
  entry margin + attributable P&L on the frozen-notional slice — that is
  the slice's own honest live worth, not contamination.
- SCOPE (Rohan): carved portion is ALREADY accounted for & wired. This is
  NOT a Fork B drag-in. The only bug: residual currently fractionalises
  the carved portion's MARGIN; it should fractionalise its EQUITY.
- **THE PATCH**: update_transaction.go L158 & L162. Today:
    sellValueInDollars = sellValueInUpsideUnits * tx.InitialPerpMargin
  Change multiplier:
    InitialPerpMargin -> carvedEquity
    where carvedEquity = InitialPerpMargin + attributablePnL (carved
    portion). attributablePnL already computed in shape
    (updatedPerpPrice - PerpMarketPrice) * Quantity (cf. DepositPriceEffect
    L222). Same file, both buy- and sell-side lines.
- Q13 RESOLVED: fraction multiplies carved-portion EQUITY (margin + P&L),
  not margin only.

#### >>> AUTO-PROTECT RE-DERIVATION (third item under the fork)
- Spreadsheet: Perp_Options_24-03-25.xlsx, tab "Auto-Protect Perp".
- Current auto-protect logic (long perp example: entry $70,532, 10x,
  liq $65,242):
  - SELL band inner = (1 + 1/lev)*entry = $77,585 — trader sells perp
    profit above ~+10% (one margin's worth of upside). Barrier on upside.
  - BUY band: F13 = liqPrice*(1+buffer) ~ $66,547; G13 = liqPrice*(1-0.3)
    ~ $45,669 — protection pushes liquidation floor down ~30%.
  - Premium from sold upside funds bought floor-pushaway. Cash-conserving.
- THE BUG: floor-pushaway is sized as a FIXED FRACTION — param D8 = 0.3
  (Floor Protection). It's a geometric assumption decoupled from what the
  protection is actually WORTH.
- The quandary (Rohan): barrier-option valuation makes the OTM protection
  leg worth MORE than a margin-only model assumes — it bears PROFITS too
  (once spot enters the protected region the bought leg accrues intrinsic
  perpMark - entrySpot; it's a live fraction of a perp valued on EQUITY
  not margin — cf. the two locked patches above).
  => more protection value => floor can be pushed FURTHER than 30%.
  => current D8 = 0.3 UNDERSELLS the real liquidation-floor pushaway.
- Fix shape: auto-protect must be RE-DERIVED from the protection leg's
  actual barrier-option value, not from a hardcoded fraction. Floor moves
  as far as the correctly-valued bought leg can fund. Same finding as the
  two patches, propagated up into auto-protect sizing.
- OPEN Q14: is D8=0.3 to become a derived OUTPUT (solve floor-pushaway
  given premium budget = sold leg's barrier-option value), or kept as a
  CEILING on an otherwise-derived pushaway?
- OPEN Q15: extra protection value from — (a) sold upside leg raises more
  premium than margin-model credits (bigger budget), (b) bought floor leg
  delivers more pushaway per premium dollar, or (a)+(b) compounding?
  Rohan's msg points at (b); confirm.

### Fork B — full rework (lands WITH the closed-form engine)
- The F4/F5 path: per-piece rows, effective strike (snaps to spot ITM),
  perp-denominated settlement, frozen origin slice.
- The destination architecture.

### The decision
- A and B are NOT mutually exclusive. A can ship first into the live
  RB-tree settlement, be superseded by B when the engine swaps in.
- Real question: is A worth the work given B is coming anyway, or skip
  straight to B?
- Tension to hold: barrier intrinsic-from-entry-spot (Fork A) is correct
  BARRIER semantics; but the closed-form AMM prices the STRIKE continuum
  (intrinsic is structurally spot-vs-strike there). Same tension as the
  rebasing note. => A is a barrier-frame patch; B is strike-continuum
  native. Decide consciously, don't let A quietly become the model.
- OPEN Q12: for Fork A, is "entry-spot" the perp mark at band-open, or
  the oracle spot at band-open? (residual_bonds is fed perpMark live;
  the entry reference should match that frame.)

## 5. Open questions for Rohan
- (none pending — all open Qs parked under portfolio branch, non-blocking)

## 5c. LEAN-PROVER CONJECTURES (surfaced this session, for Aristotle)

> Three conjectures to hand to the Lean session. Each must be stated
> precisely enough to prove/refute before an Aristotle run.

### C1 — Composite-ray shortcut extends to ITM settlement
- Claim: the shortcut (theta*=sqrt(ti*to), 2sinh/2cosh forms), proven
  OTM, also holds for CLOSING / settling an ITM position IF the ITM
  strike is replaced by spot (effective-strike substitution).
- Lean statement (Identity-V-shaped, extended past the money): the
  shortcut with effective strikes (original if OTM, spot if ITM) equals
  the true legwise close value.
- TO PIN before Lean: exact effective-strike predicate — which strike
  substituted, ITM predicate per leg, spread inner-then-outer behaviour.

### C2 — No costless-collar arb in a symmetric (w=1/2) barrier pool
- Claim: at w=1/2, V_sell=V_buy + wing-symmetric mark => no composition
  of collar legs yields free value (capital-efficiency surplus = 0).
- Sharpening of the paper's "No internal arbitrage" — specifically the
  costless-collar version, conditioned on zero skew.
- Lean statement: for w=1/2, bought-leg value attainable for a given
  V_sell budget is exactly mirror-symmetric to the sold leg — no strict
  surplus. Algebraic identity on mark symmetry.

### C3 — No-arb is a SYMMETRY phenomenon, not an INSTRUMENT phenomenon
- Claim: a DIFFERENT symmetric pool (log/exp curve shape, not
  x^w*y^(1-w)) with a DIFFERENT instrument (perpetual American call, the
  power-law value family V=A*(S/K)^gamma) gives the SAME no-free-arb
  result. => result is driven by pool symmetry, not the barrier
  instrument or the specific invariant.
- Most ambitious; needs the most spec work. "Log/exp shape" = a CFMM
  whose curve is symmetric under asset<->cash leg swap.
- OPEN Q35: full generality (any leg-swap-symmetric curve) vs two
  concrete instances (Balancer curve + a specific log/exp curve), with
  the generality claim made informally from the two. Lean toward two
  instances given AfT timing.
- OPEN Q36: handoff as a scoped Lean-session prompt — one prompt for all
  three, or one per conjecture (Aristotle runs cleaner scoped tight)?

### Lean prompts PRODUCED (4 files in /mnt/user-data/outputs, run parallel)
- lean_prompt_C1.md — shortcut extends to ITM settlement (effective
  strike). First deliverable: pin the effective-strike predicate.
- lean_prompt_C2.md — no costless-collar surplus at w=1/2 (cleanest;
  algebraic identity on mark wing-symmetry).
- lean_prompt_C3.md — symmetry-not-instrument, TWO instances (Balancer/
  barrier ref + log-exp curve / perpetual American call).
- lean_prompt_C4.md — META consistency theorem (W1-W5). W5 is the key:
  no-arb shown CONDITIONAL (zero at w=1/2, non-zero under skew) — an
  unconditional no-arb would be the bug-signature. Explicit scope limit:
  (a) model-internal consistency only, NOT (b) code-faithfulness.
- All four carry honest-framing: "no sorry" != "no axioms"; explicit
  axiom inventory required.
- Q35 RESOLVED: C3 = two instances, not full generality.
- Q36 RESOLVED: separate prompts, run parallel.
### C3 ARISTOTLE RESULT — received, assessed (run c03dbdfb)
- Status: 3 Lean files compile, no sorry. Standard axioms only
  (propext, Classical.choice, Quot.sound).
- WHAT IS GENUINELY PROVEN:
  - Abstract framework: surplus_antisymmetric, surplus_zero_at_one,
    surplus_zero_expectation, costless_at_one_of_reflection — real
    tactic proofs. Given reflection property => surplus antisym & zero
    at S=1. Airtight.
  - Both pool CURVES symmetric (sqrt x*sqrt y, exp(-x)+exp(-y)) — proved
    by ring.
  - Both instances factor through the SAME abstract theorem — the
    instrument-agnostic conditional is honestly demonstrated.
- THE CAVEAT (significant — do not skip):
  - The link curve-symmetry -> instrument reflection V_sell(S)=V_buy(1/S)
    is an AXIOM (InstanceAData.reflection / InstanceBData.reflection),
    NOT proven. That arrow IS the economic content.
  - Chain: curve symmetry -> [ASSUMED] -> reflection -> [PROVEN] -> zero
    surplus. C3 proves "IF legs reflect, surplus zero." It does NOT
    prove "pool symmetry CAUSES the reflection."
  - => C3 proved the CONDITIONAL SKELETON, not the CAUSAL claim.
    "Symmetry not instrument" holds for the conditional, not the full
    phenomenon.
- WEAK SPOTS:
  - expPool_is_not_balancer proved with witness (0,0) — nearly vacuous
    (functions differ at origin; not structural curve-family
    distinctness).
  - perpCallValue / PerpCallParams DEFINED but never USED in
    instanceB_zero_surplus — the instrument is decorative to the proof.
- IMPLICATION: makes C4 more important — its W5 (no-arb must BREAK under
  skew) tests whether `reflection` is a genuine consequence or a
  too-strong assumption.
- OPEN: possible C3-redo — derive reflection from curve symmetry + an
  instrument-pricing assumption, rather than assuming it whole. Decide
  vs "conditional skeleton is enough for the paper."

### C4 ARISTOTLE RESULT — received, assessed (run 762118ab)
- Status: C4.lean compiles, no sorry. STANDARD AXIOMS ONLY — NO domain
  axioms (verified). All admissibility conditions are explicit
  hypotheses, not assumed `axiom` declarations.
- STRONGER THAN C3, and different in kind:
  - C3 AXIOMATIZED the load-bearing step (reflection property assumed).
  - C4 DEFINES mark concretely: markCallOTM = (s/theta)^sNormCall(w),
    sNormCall(w)=(1-w)/w — and DERIVES everything. No axiom for the
    economic content.
- W5_iff — THE RESULT WANTED, properly proven:
    (forall theta>1, collarSurplus theta w = 0)  <->  w = 1/2
  Genuine biconditional. Surplus zero for all strikes IFF symmetric.
  Proof real: reduces to sNormCall(w)=sNormPut(w) <=> (1-w)^2=w^2
  <=> w=1/2; reverse via log + rpow exponent injectivity. Both
  W5_forward and W5_backward (skew => explicit nonzero surplus at
  theta=2) are real tactic proofs.
- => THE ANTI-BUG CHECK PASSES. No-arb DISCRIMINATES: true at w=1/2,
  FALSE under skew, explicit counterexample. NOT a definitional
  artifact. The no-arb result has genuine structural content.
- => Also retroactively backfills C3's axiomatized gap, for the
  Balancer/barrier case: C4 shows symmetry falls out of the concrete
  mark formula at w=1/2, no reflection axiom needed. C3 = breadth
  (instrument-agnostic, axiomatized); C4 = depth (concrete,
  Balancer-only). Complementary.
- CAVEATS (smaller this time):
  - collarSurplus = pure mark difference (pricing asymmetry), not full
    dollar collar P&L. Right object for "no free PRICING edge";
    consistent with the no-CASH-arb framing, not a risk-mgmt-value claim.
  - C4_jointConsistency closed with `grind +suggestions` (heavy
    automation) — compiles, low-risk (just conjoins the transparent
    W1-W5), but the one theorem not eyeball-checkable.
  - W4 (effective strike) theorems real but light — mostly the OTM
    identity; substantive ITM content thinner than W1/W5.
- NET: solid validation. No-arb is structural, not a bug. Conditional
  on symmetry, skew breaks it, no domain axioms, real biconditional.

### C1 ARISTOTLE RESULT — received, assessed (run a47ea888)
- Status: CompositeRayITM.lean compiles, no sorry, standard axioms only.
- GENUINE PASS. identity_V_call proved INLINE (real algebra through
  sinh/exp/log/sqrt — not axiomatized). Main theorem case-splits on spot
  vs the two strikes; all 3 cases (both OTM / inner ITM / both ITM)
  proved. Effective-strike predicate confirmed as drafted.
- Honest note: both-ITM case, both sides collapse to 0 (composite =
  mark*2sinh(0)=0; legwise = 1-1=0). Identity holds but trivially there.
  Correct value, just worth knowing "works fully ITM" partly means
  "both sides zero".
- C1 genuinely proves what it set out to. ITM shortcut validated.

### C2 ARISTOTLE RESULT — received, assessed (run ee5b6b3a) — WEAK
- Status: compiles, no sorry, standard axioms — BUT the headline
  theorem does NOT prove what it claims.
- C2_no_collar_arbitrage: `(h_cash: sellValue=buyValue) -> surplus=0`.
  surplus := buyValue - sellValue. So it's `a=b |- b-a=0` — a
  TAUTOLOGY. The "no arb" conclusion is literally the hypothesis
  restated. h_mirror unused (underscore). The mark/symmetry machinery
  untouched by the main theorem.
- The intended content (symmetry FORCES V_sell=V_buy) is ASSUMED, not
  derived. Same flaw as C3 but worse — C3 proved real consequences from
  its assumption; C2's headline proves nothing.
- SALVAGEABLE parts (genuinely proved, use only as supporting lemmas):
  - markCall_eq_markPut_mirror — call@theta = put@(1/theta) at sNorm=1.
  - C2_notional_equality — cash-conservation + mirror => N_buy=N_sell.
- SAVING GRACE: C2's intended result is ALREADY properly proven by C4's
  W5_iff (derived from the concrete mark formula, real biconditional,
  skew counterexample). => Do NOT cite C2 as the no-arb proof. Cite C4.
  C2 file = redundant-to-weak; keep only for the notional-equality lemma.

### >>> NET PICTURE — all 4 Lean conjectures back
- C1: genuine pass — ITM shortcut proven, predicate confirmed.
- C2: headline tautology — real no-arb content ABSENT here, but covered
  by C4. Keep C2 only for notional-equality lemma.
- C3: conditional skeleton proven, instrument-agnostic; causal step
  (symmetry->reflection) axiomatized.
- C4: THE STRONG ONE — no-arb proven structural (biconditional, skew
  breaks it), no domain axioms. THIS is the no-arb citation.
- BOTTOM LINE: the thing wanted — "no-arb is real, not a bug" — IS
  established, by C4. C2's failure to prove it independently doesn't
  change that; it just means cite C4, not C2.

## 5b. Cross-session handoff
- **paper_diff_brief.md** produced -> /mnt/user-data/outputs/paper_diff_brief.md
  - Conceptual/high-level design picture for the AfT paper session.
  - Diff-enabling brief: lists conceptual elements to check the draft against.
  - 4 paper-relevant mechanics surfaced this session:
    1. band protects origin perp; settlement perp-denominated
    2. perp aggregation model + frozen origin slice
    3. effective strike = close/exercise mechanism
    4. one-shot composite-ray band closure
  - Implementation/UI fenced to annexure-level / out of scope.
  - Attach alongside Temporal_Paper_AfT_2026_v6.docx in paper session.

---

## 6. Intuition recaps (periodic collapses)

### Recap 1 — what this session has converged on
The portfolio findings (F1-F5) all collapse into ONE idea: **make the
band's origin and per-piece structure legible, because settlement is
perp-denominated and attribution must stay clean.**
- A band is carved from an aggregated perp -> it must carry a frozen,
  immutable origin slice {notional, equity, mark} so settlement isn't
  contaminated by later perp activity.
- A band has up to 4 pieces -> portfolio should show them per-piece, each
  with original + effective strike, because effective strike (snaps to
  spot when ITM) is exactly the info closure needs.
- Closure itself stays one-shot (composite-ray clubs the pieces) — the
  per-piece view is for legibility, not execution granularity.
The old portfolio "hid and aggregated away" precisely this structure;
the closed-form upgrade is the moment to expose it cleanly.
