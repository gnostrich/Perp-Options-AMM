# Context — distilling theory from the unified-pool warp implementation

## ROOT: what the HTML implements
- AMM curve: `x^w · y^(1-w) = k`
- Trade is parameterized by polar angle θ at point `(x_*, y_*)` on the curve
- Effective per-trade price `P_eff_raw = dx/dy` (slippage-inclusive secant slope)
- **Warp rule** (the non-standard piece):
  - Hold trade point `(x_*, y_*)` FIXED (reserves do NOT update)
  - Pick `w_new = x_* / (x_* + P_eff · y_*)` so new tangent at `(x_*, y_*)` equals `P_eff`
  - Pick `k_new = x_*^w_new · y_*^(1-w_new)` so new curve passes through `(x_*, y_*)`
- Net: slippage is paid by **deforming the pricing curve** (weight + scale), not by sliding reserves along a fixed curve
- Sequential legs compose: warp₁ output state seeds warp₂

## BRANCH 1: local point invariants on `x^w y^(1-w) = k`
- Mode angle: `tan(θ_m) = (1-w)/w`  →  ATM where call = put = 1
- At polar angle θ:
  - `|slope|(θ) = (w/(1-w)) · tan(θ) = tan(θ)/tan(θ_m)`
  - `P(θ) = ((1-w)/w) · cot(θ) = tan(θ_m)/tan(θ)`
  - **`P(θ) · |slope|(θ) = 1`** identically (tautology dx/dy · dy/dx = 1, but useful)
  - **`P(θ) · tan(θ) = tan(θ_m)`** ← invariant in θ along a given pool

## BRANCH 2: log-log linearization → curve is a straight line
- Let `u = ln x`, `v = ln y`
- Curve: `w·u + (1-w)·v = ln k`  (straight LINE)
- Line angle in (u,v): `tan φ = -w/(1-w)`  ← encodes pool weight
- ATM/mode = where line crosses `u = v` (so `v - u = 0`, i.e. y = x)

## BRANCH 3: rapidity ξ = ln(tan θ) = v − u as natural coordinate
- Along the curve: `ln |slope| = ξ − ξ_m`, where `ξ_m = ln tan(θ_m) = ln((1-w)/w)`
- **Log-slope is AFFINE in rapidity with coefficient EXACTLY 1**, regardless of w
- Pool weight w only translates the origin (ξ_m). It does NOT bend the relationship.
- Consequence: in (ξ, ln|slope|) coordinates, every pool is the same line shifted

## BRANCH 4: reciprocal-slope symmetry (the HTML's ratio panel)
- Pair: slope `−m` above mode, slope `−1/m` below mode
- **Prices identically equal** (= 1/m) regardless of w → asymmetry can't show in prices
- Rapidity displacements: `Δξ_C = +ln m`, `Δξ_P = −ln m`  ← equal magnitudes
- **`tan(θ_C) · tan(θ_P) = tan²(θ_m)`** — mode is geometric center of reciprocal pairs
- Polar-angular distances Δθ_C, Δθ_P are NOT equal unless w = 0.5 → ratio panel bows

## BRANCH 5: the conservation law you asked about
- Take any point P_* on the curve at rapidity ξ_*. Walk ±Δξ along the curve.
- Slope at ξ_* + Δξ: `|slope|(P_*) · e^(+Δξ)`
- Slope at ξ_* − Δξ: `|slope|(P_*) · e^(−Δξ)`
- **Product: `|slope|(P_+) · |slope|(P_−) = |slope|(P_*)²`** for any Δξ
  - i.e. local slope is geometric mean of equal-rapidity neighbors
- Sum of integrated slopes: `slope(P_*) · 2 sinh(Δξ)`
- Product of integrated slopes: `slope(P_*)² · 2(cosh Δξ − 1)`
- Slope integrals above/below pack into **hyperbolic-trig of rapidity** → Minkowski signature
- This is the multiplicative invariant your intuition was tracking: the curve carries a natural Lorentzian structure in (rapidity, log-slope), and "what's above" times "what's below" at matched rapidity is locked.

## BRANCH 6: what warp preserves / shifts
- Preserves: trade point `(u_*, v_*)`, hence its rapidity `ξ_* = v_* − u_*`
- Shifts: line-angle φ (rotation about `(u_*, v_*)` in log-log)
  - encodes Δw — the only intrinsic "trade size" in pool-space
- Mode rapidity ξ_m shifts: `ξ_m^(1) − ξ_m^(0) = ln((1-w₁)/w₁) − ln((1-w₀)/w₀)`
- Trade point's rapidity-distance-from-mode `ξ_* − ξ_m` therefore shifts oppositely
- **Warp = pure rotation of the log-log line about the fixed trade point**
- Composition: rotations about same point add → multi-leg warps are abelian in line-angle

## BRANCH 7: strike conventions
- HTML uses additive strike `s` with `K = 1 ± s/100`, then `tan θ = K^(1/w) tan θ_m`
- Natural rapidity-form strike: `Δξ = (ln K)/w`
- **Multiplicative strike symmetry** (call K and put K' with K · K' = 1) gives equal-rapidity offsets from mode — the true symmetry the curve respects
- Additive strike symmetry (+30% / −30%) is NOT the geometric symmetry; it's a UI choice

## BRANCH 8: formalization (this turn — litepaper-style writeup)
- §1 Setup: curve, polar angle, log-log linearization, rapidity ξ=v−u
- §2 Local invariants: Prop 1 (ln σ = ξ − ξ_m), Cor (σP = 1)
- §3 Conservation: Thm 1 (σ(ξ+Δξ)·σ(ξ−Δξ) = σ(ξ)²), Cor (sinh/cosh slope integrals)
- §4 Reciprocal-slope pairs: Prop 2 (price-equal, rapidity-mirrored, tan-product = tan² θ_m)
- §5 Warp dynamics: warp rule, Prop 3 (warp = rotation in log-log about trade pt), Thm 2 (Δξ_m = ln(P_eff/P_0))
- Compact identity: slippage = e^(Δξ_m) − 1
- TikZ figure: log-log line rotating about trade point; mode slides along diagonal u=v
- Output: LaTeX → PDF to /mnt/user-data/outputs/

## BRANCH 9: review of updated HTML model (this turn)
- Two panel changes; one substantive, one rhetorical
- **Pricing panel — substantive reframing**:
  - OLD x-axis: Δθ from mode (mode-relative; strike's x-position shifts with mode)
  - NEW x-axis: absolute strike polar angle θ ∈ [0°, 90°] — **trade-invariant strike identifier**
  - OLD y-axis: option price P(θ)
  - NEW y-axis: polar-angle ratio ψ (= θ/θ_m for puts, θ_m/θ for calls); peaks at 1 at mode
  - Net: chart now shows mode "tent" SLIDING across fixed strike-θ-space as trades shift θ_m
  - Strong alignment with rapidity formalism: strike = ξ_strike (fixed), mode = ξ_m (moves), gap (ξ_strike − ξ_m) determines effective price
  - Observation surfaced: strikes between θ_m⁽⁰⁾ and θ_m⁽¹⁾ **flip type** (call↔put)
- **Ratio panel — narrative shift, math identical**:
  - Same parametric (Δθ_C(m), Δθ_P(m)) trajectory
  - Description repointed from "reciprocal-slope = price-equal pairs" to "endpoint at m→∞ swings off diagonal with tilt"
  - Substance unchanged; emphasis moved from price-equality property to endpoint geometry
- **ψ caveat**: ψ is not the option price; it's a viz proxy
  - True prices: P_call = tan(θ_m)/tan(θ), P_put = tan(θ)/tan(θ_m)
  - Same qualitative shape (peak 1 at mode, 0 at extremes) but ψ ≠ P
  - Decision pending: is ψ deliberate, or should y-axis be P directly?
- **Propagation to LaTeX**:
  - Core formalization holds — no revisions required
  - Candidate addition: Corollary (Strike type-flip) under Thm 2:
    > A trade with Δξ_m = ln(P_eff/P_0) flips the type (call↔put) of every strike whose rapidity ξ_strike lies between ξ_m⁽⁰⁾ and ξ_m⁽¹⁾.
  - Holding for approval

## BRANCH 10: full recheck of LaTeX against HTML as canonical (this turn)
- **Issue 1 — Prop 2(iii) is wrong as stated.**
  - Wrote: "P(ξ_C) = P(ξ_P) = 1/σ_C" where P = -dx/dy
  - But marginal P at C = 1/σ_C and marginal P at P = 1/σ_P = σ_C — these are RECIPROCALS, not equal
  - Source of error: conflated "marginal price" (universal -dx/dy) with "option premium" (side-specific)
  - Correct statement: **call premium at C = put premium at P = 1/σ_C**, since put premium = 1/marginal
- **Issue 2 — P needs side-specific naming.**
  - HTML distinguishes P_C (call side, = P_raw = 1/σ) from P_P (put side, = 1/P_raw = σ)
  - LaTeX uses generic P = -dx/dy; works for marginal/slope statements but ambiguous for option-price statements
  - Fix: introduce both P_C(θ), P_P(θ); note P_C · P_P = 1; show ln P_C = ξ_m - ξ, ln P_P = ξ - ξ_m
- **Issue 3 — Slippage corollary has side-dependent sign.**
  - Current: s = e^(Δξ_m) - 1
  - Correct: s_call = e^(Δξ_m) - 1; s_put = e^(-Δξ_m) - 1
  - Because in HTML: slip_pct uses option-price ratio, not marginal-price ratio
- **Addition — Strike type-flip corollary.**
  - Strike at ξ_strike strictly between ξ_m^(0) and ξ_m^(1) flips type (call↔put) under trade
  - Clean consequence of Thm 2; visualized in new pricing panel
- **Addition — Strikes as trade-invariant rapidities (new §1.5).**
  - Strikes identified by θ_strike (= ξ_strike in log-tan); intrinsic to (x, y) plane
  - "% from spot" is a dynamic reading that depends on current θ_m
  - This is the conceptual content of the new pricing panel's x-axis choice
- **Non-issue — ψ in viz.**
  - ψ is a viz proxy, not a fundamental quantity; LaTeX doesn't need it
  - Canonical option price already defined cleanly in revised §1.3

## BRANCH 11: Aristotle / Lean 4 prompt (this turn)
- Goal: hand off the formalization in warp-amm.tex to Aristotle for machine-checked Lean proof
- File: `Warp.lean` under namespace `Temporal.Warp`
- Definitions: σ, ξ, ξ_m, P_C, P_P (in θ), σ_ξ, P_C_ξ, P_P_ξ (in rapidity), warp w₁, k₁
- Theorems: Prop 1, premium duality, Thm 1, hyperbolic integrals cor, Prop 2 (i)-(iv), Prop 3 (warp preserves pivot, warp tangent = P_eff), Thm 2, premium impact cor, slippage cor, type-flip cor
- Style: rapidity-parameterized variants for clean exp arithmetic; bridge to θ-parameterized via Prop 1
- Mathlib hits: Real.log_mul/div/inv/exp, Real.exp_add/neg/sub, Real.tan_pos_of_pos_of_lt_pi_div_two, Real.sinh/cosh
- Output: `lean-prompt.md` to /mnt/user-data/outputs/

## BRANCH 12: Aristotle output audit (this turn)
- File received: `RequestProject/Warp.lean`, ~200 LOC
- Aristotle claim: 22/22 theorems proved, zero sorry, only standard axioms (`propext`, `Classical.choice`, `Quot.sound`), Mathlib v4.28.0
- Cannot recompile in sandbox: elan/Mathlib network downloads blocked
- Static audit of theorem statements:
  - All 22 statements match LaTeX claims faithfully
  - Coverage 1:1 with prompt (defs, Prop 1, Cor §2, Bridge, Thm 1 ξ+θ, hyperbolic integral sum/prod, Prop 2(i)-(iv), Prop 3 split, Thm 2, premium impact C/P, slip C/P, type-flip)
  - Two clean reformulations (good):
    - `slope_product_θ` stated with `htan : tan θp * tan θm = (tan θ)²` (tan-product condition) rather than Δξ — cleanest θ-form
    - `strike_type_flip` uses `min/max` framing — matches LaTeX exactly
- Static audit of proofs:
  - 20/22 proofs structurally sound on inspection (def unfolds, exp/log algebra, ring, field_simp, linear_combination)
  - **Suspicion: `slope_integral_sum`** — proof uses `rw [Real.sinh_eq]; ring; simpa ...` without explicit integral evaluation. `ring` cannot simplify across integral terms; either Mathlib auto-simp covers it or the proof fails to compile. Aristotle claims it does.
  - **Suspicion: `slope_integral_prod`** — similar shape but uses `intervalIntegral.integral_comp_sub_right` via `norm_num` — more plausible
  - Both warrant local `lake build` verification before trusting
- Recommendation to user: run `lake update && lake build` locally to confirm. If integral proofs fail, restructure with explicit `intervalIntegral.integral_exp` evaluation step.

## INTUITION COLLAPSE (this session)
- Forget reserves. Forget x and y. Work in `(u, v) = (ln x, ln y)`.
- Curve = straight line. Weight = line's angle. Trade = rotate the line about the trade point.
- Polar angle in (x,y) → **rapidity** `ξ = v − u` in log-log. This is the curve's intrinsic coordinate.
- log-slope = ξ − ξ_m, slope-1 affine in ξ. The pool only chooses where ξ_m sits.
- "Above" and "below" any point on the curve are mirror-symmetric in rapidity: slopes at ±Δξ multiply to slope² at the point. This is the hidden conservation.
- Reciprocal-slope pairs above/below the mode price-equal but rapidity-mirror; mode is the geometric center.
- Slippage of the implementation = the line's rotation angle Δφ about the trade point.
- The whole AMM is a 1-D rapidity object with an arbitrary origin (ξ_m) and scale (k). Everything else is decoration.
