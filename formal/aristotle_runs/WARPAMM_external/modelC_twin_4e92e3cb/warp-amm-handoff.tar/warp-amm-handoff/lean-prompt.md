# Warp AMM — Lean 4 verification prompt (Aristotle)

## Mission
Produce a Mathlib-compiling Lean 4 file `Warp.lean` under namespace `Temporal.Warp` that formalizes and machine-checks every numbered claim in `warp-amm.tex`. Each Lean `theorem` should carry a comment referencing the LaTeX label (`-- Prop 1 (§2)`, `-- Thm 2 (§5)`, etc.).

## Domain conventions
- All reals (`ℝ`).
- Pool: `w : ℝ` with `0 < w < 1`; `k : ℝ` with `0 < k`.
- Reserves / trade-point coords: `x y : ℝ`, both `> 0`.
- Angle: `θ : ℝ` with `0 < θ < π/2` (so `Real.tan θ > 0`).
- All logarithms are over strictly positive arguments — keep positivity hypotheses explicit.
- Functions involving `Real.log`, `Real.tan` etc. are `noncomputable`.

## Two parameterizations (define both; bridge with Prop 1)

The geometric (θ-) parameterization stays close to the LaTeX. The rapidity (ξ-) parameterization makes Thm 1 and the hyperbolic identities trivial via `Real.exp_add`. Prove the theorems in whichever parameterization is cleaner; provide the θ-side as a corollary by Prop 1.

```lean
namespace Temporal.Warp

-- θ-parameterized
noncomputable def σ_θ (w θ : ℝ) : ℝ := (w / (1 - w)) * Real.tan θ
noncomputable def ξ_m (w : ℝ) : ℝ := Real.log ((1 - w) / w)
noncomputable def ξ (θ : ℝ) : ℝ := Real.log (Real.tan θ)
noncomputable def P_C_θ (w θ : ℝ) : ℝ := ((1 - w) / w) / Real.tan θ
noncomputable def P_P_θ (w θ : ℝ) : ℝ := σ_θ w θ

-- ξ-parameterized
noncomputable def σ_ξ (ξm ξ : ℝ) : ℝ := Real.exp (ξ - ξm)
noncomputable def P_C_ξ (ξm ξ : ℝ) : ℝ := Real.exp (ξm - ξ)
noncomputable def P_P_ξ (ξm ξ : ℝ) : ℝ := Real.exp (ξ - ξm)

-- Warp
noncomputable def w₁ (xs ys P_eff : ℝ) : ℝ := xs / (xs + P_eff * ys)
noncomputable def k₁ (xs ys w : ℝ) : ℝ := xs ^ w * ys ^ (1 - w)

end Temporal.Warp
```

## Theorems

```
-- Prop 1 (§2) — log-slope affine in rapidity
log_σ_eq : 0 < w → w < 1 → 0 < θ → θ < π/2 →
  Real.log (σ_θ w θ) = ξ θ - ξ_m w

-- Cor (§2) — premia in rapidity, duality
log_P_C_eq        : Real.log (P_C_θ w θ) = -(ξ θ - ξ_m w)
log_P_P_eq        : Real.log (P_P_θ w θ) =  (ξ θ - ξ_m w)
premia_duality    : 0 < w → w < 1 → 0 < θ → θ < π/2 → P_C_θ w θ * P_P_θ w θ = 1

-- Bridge: σ_ξ ∘ (ξ_m, ξ) = σ_θ (mod positivity)
σ_ξ_eq_σ_θ        : 0 < w → w < 1 → 0 < θ → θ < π/2 →
                    σ_ξ (ξ_m w) (ξ θ) = σ_θ w θ

-- Thm 1 (§3) — slope-product invariant (do this in ξ-form first; θ-form follows)
slope_product_ξ   : ∀ ξm ξ Δξ : ℝ, σ_ξ ξm (ξ + Δξ) * σ_ξ ξm (ξ - Δξ) = (σ_ξ ξm ξ)^2
slope_product_θ   : (positivity preconds) → σ_θ w θ₊ * σ_θ w θ₋ = (σ_θ w θ)^2
                    -- where θ₊, θ₋ are derived from ξ ± Δξ via the bridge

-- Cor (§3) — hyperbolic-trig structure
slope_integral_sum :
  ∫ x in (ξ)..(ξ+Δξ), σ_ξ ξm x   +   ∫ x in (ξ-Δξ)..(ξ), σ_ξ ξm x
  = 2 * σ_ξ ξm ξ * Real.sinh Δξ

slope_integral_prod :
  (∫ x in (ξ)..(ξ+Δξ), σ_ξ ξm x) * (∫ x in (ξ-Δξ)..(ξ), σ_ξ ξm x)
  = 2 * (σ_ξ ξm ξ)^2 * (Real.cosh Δξ - 1)

-- Prop 2 (§4) — reciprocal-strike symmetry (state in ξ-form)
recip_slope_pair  : σ_ξ ξm (ξm + Δ) * σ_ξ ξm (ξm - Δ) = 1
tan_product_pair  : (positivity preconds) →
                    Real.tan θ_C * Real.tan θ_P = (Real.tan (Real.arctan ((1-w)/w)))^2
                    -- equivalently expressed in terms of ξ_m
cross_premia_eq   : P_C_ξ ξm (ξm + Δ) = P_P_ξ ξm (ξm - Δ)
cross_premia_val  : P_C_ξ ξm (ξm + Δ) = Real.exp (-Δ)
same_side_recip   : P_C_ξ ξm (ξm + Δ) * P_C_ξ ξm (ξm - Δ) = 1

-- Prop 3 (§5) — warp preserves pivot, sets new tangent to P_eff
warp_passes_pivot : 0 < xs → 0 < ys → 0 < P_eff →
                    let wn := w₁ xs ys P_eff
                    xs ^ wn * ys ^ (1 - wn) = k₁ xs ys wn
warp_tangent_eq   : 0 < xs → 0 < ys → 0 < P_eff →
                    let wn := w₁ xs ys P_eff
                    (1 - wn) / wn * (xs / ys) = P_eff
                    -- i.e. the new marginal P_C at (xs, ys) equals P_eff

-- Thm 2 (§5) — mode-rapidity shift = log marginal-price impact
mode_shift :
  0 < w₀ → w₀ < 1 → 0 < xs → 0 < ys → 0 < P_eff →
  let wn := w₁ xs ys P_eff
  let P₀ := (1 - w₀) / w₀ * (xs / ys)
  ξ_m wn - ξ_m w₀ = Real.log (P_eff / P₀)

-- Cor (§5) — premium impact at trade point
premium_impact_C  : (preconds) →
                    P_C_θ wn θ / P_C_θ w₀ θ = Real.exp (ξ_m wn - ξ_m w₀)
premium_impact_P  : (preconds) →
                    P_P_θ wn θ / P_P_θ w₀ θ = Real.exp (-(ξ_m wn - ξ_m w₀))

-- Cor (§5) — slippage (side-specific sign)
slip_call : s_call = Real.exp Δξm - 1
slip_put  : s_put  = Real.exp (-Δξm) - 1

-- Cor (§5) — strike type-flip
strike_type_flip :
  ∀ ξm₀ ξm₁ ξs : ℝ,
    (min ξm₀ ξm₁ < ξs ∧ ξs < max ξm₀ ξm₁) →
    -- the strike's side relative to mode flips
    (ξs > ξm₀ ↔ ξs < ξm₁)
```

## Proof hints

- **Prop 1**: `unfold σ_θ ξ ξ_m`; use `Real.log_mul`, `Real.log_div`, positivity of `w/(1-w)` and `Real.tan θ` on the open interval.
- **Premium duality**: from `σ_θ` and `P_C_θ = 1 / σ_θ`, immediate.
- **Thm 1 (ξ-form)**: `unfold σ_ξ`; `rw [← Real.exp_add]`; goal becomes `exp (2 * (ξ - ξm)) = (exp (ξ - ξm))^2`; close with `Real.exp_nat_mul` (or `Real.exp_two_mul`) and `sq`.
- **Hyperbolic integrals**: `intervalIntegral.integral_exp` gives `∫ exp(x - ξm) dx = exp(x - ξm)` evaluated at endpoints. Subtract endpoints, use `sinh_eq` / `cosh_eq` to identify `(exp Δξ − exp(−Δξ))/2 = sinh Δξ` etc.
- **Warp tangent**: `unfold w₁`; `field_simp` after establishing `xs + P_eff * ys ≠ 0`.
- **Thm 2**: from `warp_tangent_eq`, `(1 - wn)/wn = P_eff * (ys/xs)`. Take logs: `ξ_m wn = Real.log P_eff + Real.log (ys/xs)`. Similarly `ξ_m w₀ = Real.log P₀ + Real.log (xs/ys) ... wait — careful with sign on `xs/ys` vs `ys/xs`. The clean identity is `(1-w₀)/w₀ = P₀ · ys/xs`, parallel to `(1-wn)/wn = P_eff · ys/xs`. Subtract logs.
- **Type-flip**: pure order arithmetic on real numbers; `linarith` or case-split on signs.

## Mathlib pointers
`Real.log_mul`, `Real.log_div`, `Real.log_inv`, `Real.log_rpow`, `Real.exp_log`, `Real.log_exp`, `Real.exp_add`, `Real.exp_neg`, `Real.exp_sub`, `Real.exp_two_mul`, `Real.tan_pos_of_pos_of_lt_pi_div_two`, `Real.sinh`, `Real.cosh`, `Real.sinh_eq`, `Real.cosh_eq`, `intervalIntegral.integral_exp`, `field_simp`, `div_pos`, `mul_pos`, `linarith`, `nlinarith`, `ring`, `ring_nf`.

## Output expectations
- Single file `Warp.lean` compiling under current Mathlib without `sorry`.
- One `theorem` per claim above; preserve names verbatim where given.
- Each theorem prefaced with a one-line LaTeX-label comment.
- Positivity hypotheses stated explicitly per theorem (do not pull them from a global `variable` block — Aristotle-friendly: each statement self-contained).
- Where the LaTeX uses real-analysis closure (`log_mul`, `exp_add`, etc.), use Mathlib lemmas directly; do not re-prove ladder lemmas.
- Use `noncomputable` on every definition touching `Real.log`, `Real.tan`, `Real.exp`, or `Real.rpow`.

## Known gotchas
- `Real.log_rpow` requires `0 < x`; ensure positivity of `xs, ys` before unfolding `k₁`.
- `(1 - w)/w > 0` requires both `0 < w` and `w < 1`; carry as hypotheses.
- `Real.tan` is undefined at `π/2`; the open interval `(0, π/2)` is enough but tactics may need `Real.cos_ne_zero_iff` or similar.
- For `slope_product_θ`, the θ ↔ ξ bridge requires positivity of `Real.tan` at `θ₊, θ₋`; carry these as hypotheses or derive them from `0 < θ₊ < π/2`.

## Source reference
All claims are exactly those in `warp-amm.tex` (§1–§6). Treat that document as ground truth; the prover's job is machine-checking, not re-deriving.
