# Temporal — staging comparison test kit

Self-contained kit for testing `https://app-staging.temporal.exchange/` against the verified
reference build. Everything needed to make the comparison **mechanical and provable** is here; no
access to the main repo is required (though repo write access is useful for committing evidence).

## Read in this order
1. **`SOP.md`** — the airtight comparison protocol (rules of evidence, wallet setup, test matrix,
   version identification, deliverable format).
2. **`MEMO_expected_values.md`** — the golden numbers with provenance + the DO-NOT-FALSE-FLAG list +
   the known staging-side endpoint gap.
3. **`golden/GOLDEN_harness_output.txt`** — the reference build's own gate output (41 PASS / 0 FAIL +
   5 PASS / 0 FAIL). Reproduce it (step 2 of the SOP) before trusting any golden value.

## Contents
```
builds/                                         (harness expects this dir as ../builds)
  HEAD_temporal_mvp_v28_lens.html               THE reference ("H3, Jul 8", md5 5ce1a76c) — what staging should match
  temporal_mvp_v24_rebase_fixed_2.html          plain v24 base (the harness reads this for the m=1 checks)
  temporal_mvp_v28_lens_twocaseclose.html       prior close model (to identify if staging lags)
  MD5SUMS.txt
harness/                                        pure Node (fs/vm/path only — NO npm install)
  lens_selfcheck.js    node lens_selfcheck.js <build>   → 41 numeric checks
  a16_atm_gate.js      node a16_atm_gate.js <build>     → 5 continuity checks
  run_all.sh           sh run_all.sh <build>            → integrity + both gates
  vocab_gate.sh        (repo hygiene; not needed for the comparison)
reference_docs/
  CHANGELOG_for_CTO.pdf / .html                 plain-English "what changed + numbers to reproduce"
  CTO_CHANGELOG_80f050e2_to_current_2026-07-03.md  technical changelog from the CTO's baseline
  UPDATE2_TBD_spec.md                           what is deliberately NOT built yet (don't false-flag)
  VOCABULARY.md                                 endorsed terms ("ray deviation", never "lean")
  feature_inventory.md                          the full feature checklist
tester_charter/
  tester_agent_charter.md                       the persona/discipline to run this as (FLAG verdicts, no eyeballing)
golden/
  GOLDEN_harness_output.txt                     reference build gate output, 41+5 PASS
SOP.md · MEMO_expected_values.md · MANIFEST_MD5.txt · README.md
```

## Integrity
Reference build: `md5 5ce1a76c7b75ec3763fda6df9538a841`. Prior-close twin: `md5 513425747b23b74cb07c0fda4959825b`.
Verify everything against `MANIFEST_MD5.txt`: `md5sum -c MANIFEST_MD5.txt` (run from the kit root).

## How to run the reference locally (no install)
```sh
node harness/lens_selfcheck.js builds/HEAD_temporal_mvp_v28_lens.html   # expect 41 PASS / 0 FAIL
node harness/a16_atm_gate.js  builds/HEAD_temporal_mvp_v28_lens.html   # expect 5 PASS / 0 FAIL
```
The reference build is a single HTML file; the harness sandboxes its `<script id="engine">` in Node's
`vm` and asserts the numbers in `MEMO_expected_values.md`. Requires Node ≥ 18.

## Not included (and why)
- **The CTO's baseline build `80f050e2` (14 Jun) HTML** — not retained as a file; only its changelog is
  (`reference_docs/CTO_CHANGELOG_80f050e2_to_current…md`). The comparison target is the current reference
  (`5ce1a76c`); the baseline is context only.
- **A funded wallet / private key** — generate a throwaway testnet key yourself (SOP). Never a real seed.

## The point of this kit (why it exists)
The first staging comparison was doubted because it leaned on rounded UI reads and single samples. This
kit forces: verify integrity → reproduce the golden → measure staging at full precision into files →
pair every number with a golden value + tolerance → multi-sample any "change" claim → mark BLOCKED
(not PASS) when staging doesn't expose the quantity. Follow `SOP.md` exactly.
