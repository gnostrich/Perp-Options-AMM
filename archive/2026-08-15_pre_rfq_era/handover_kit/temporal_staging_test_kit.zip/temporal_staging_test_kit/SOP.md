# SOP — staging comparison test (airtight protocol)

Target: `https://app-staging.temporal.exchange/` (Hyperliquid-testnet on Arbitrum-Sepolia).
You are testing whether staging reproduces the **reference build** in `builds/`
(`builds/HEAD_temporal_mvp_v28_lens.html`, md5 `5ce1a76c7b75ec3763fda6df9538a841` = "H3, Jul 8").
Goal: a comparison that is **mechanical and provable**, not eyeballed. Every claim carries a paired
golden value + a full-precision measured value + a delta + a tolerance, or it is marked BLOCKED.

## Rules of evidence (these are what make it airtight)
1. **Integrity first.** Verify the reference build + harness md5s against `README.md` / `MD5SUMS.txt`
   before trusting any golden number.
2. **Reproduce the golden locally.** Run `node harness/lens_selfcheck.js <ref-build>` and
   `node harness/a16_atm_gate.js <ref-build>`; confirm **41 PASS / 0 FAIL** and **5 PASS / 0 FAIL**
   matching `golden/GOLDEN_harness_output.txt`. If they don't match, STOP — your kit is corrupt.
3. **Full precision, saved to files.** NEVER compare rounded UI text. For every staging quantity, capture
   the raw full-precision value (API/websocket payload or `amm-status`-style read) **to a file**, and
   compute deltas from the files. (Lesson from the first attempt: at rounded precision β looked like it
   moved 0.14 when Δβ was exactly 0. Rounding hid the truth in both directions.)
4. **One sample is "directional", not "proven".** Any claim about a *change* (e.g. "close reverses the
   warp") needs ≥3 independent trials, ideally on a freshly-reset pool, before you call it PASS. Label a
   single before/after as DIRECTIONAL.
5. **Determinism control.** Re-run the identical action from the identical starting state; the result must
   be identical. If it drifts, that's a finding (non-determinism / shared-pool interference), not noise to
   average away.
6. **Pair-or-block.** A check is PASS/FAIL only if you have BOTH the golden value (MEMO §1–4) and a
   full-precision staging value. If staging doesn't expose the needed quantity, mark
   **BLOCKED — needs endpoint** (see the known per-strike-endpoint gap in MEMO), and say exactly which
   endpoint the CTO must expose.

## Wallet (throwaway testnet only)
Generate a FRESH testnet private key (Arbitrum Sepolia); inject a headless EIP-1193 provider OR use
MetaMask+Synpress. NEVER use or request a real seed; read the key from an env var/secret, never chat/logs.
Fund via faucets if placing trades; else run connect-only and say so.

## Test matrix (priority order — highest-confidence first)
| # | check | how to measure on staging | golden (MEMO) | verdict rule |
|---|---|---|---|---|
| A | **Balanced-pool funding = 0** | read funding on a symmetric/w=0.5 pool at several strikes | §3: exactly 0 ∀ strikes | any non-zero = REGRESSION |
| B | **Trade warps at trade point; α,β conserved; w moves** | before/after full-precision amm-status around one trade; compute Δα,Δβ,w′ from files | §2: Δα=Δβ=0 (machine-eps), w′=11/21 for the exhibit pool/trade | Δα or Δβ ≠ 0 at full precision = FAIL |
| C | **w′ exhibit** (if you can set pool=(10,10,.5), θ=4, dy=+1) | read w′,x′,y′,Δx | §2: 11/21, 215/22, 11, −5/22 | 22/43 or 6/11 ⇒ OLDER build |
| D | **Funding zero ITM / zero ATM** | funding across OTM→ATM→ITM on a skewed pool | §3: 0 at ATM and ITM, lobe OTM | non-zero at ATM/ITM = FAIL |
| E | **Close is one sell-back path, payout continuous** | close ITM and OTM legs; check payout continuity across the strike (no ~½ jump) | §4 | a ~½ jump ⇒ OLD two-case close (compare vs bundled PRIOR build) |
| F | **Option value + seams** ($66.67/0.148/etc.) | needs a per-strike/curve endpoint | §1 | if no endpoint ⇒ BLOCKED (name the endpoint) |

## Version identification
Report which reference version staging matches, using the unique-to-H3 signatures: (i) trade α,β
conserved + w moves, (ii) close returns pool toward balanced, (iii) balanced pool ⇒ funding 0. If all
three hold, staging = H3 (`5ce1a76c`). If any fail in the older direction, name which version it looks like
(H1=v24 / H2=Jun15) and cite the measured evidence.

## Deliverable
A report with: (1) integrity + golden-reproduced confirmation; (2) the test matrix filled in with
PASS/FAIL/DIRECTIONAL/BLOCKED, each row carrying golden value, full-precision measured value, delta,
tolerance, and the saved-file path; (3) screenshots per flow; (4) console/network errors; (5) a
divergence list vs the reference with evidence; (6) the throwaway wallet ADDRESS (never the key); (7) an
explicit statement of how far the trade flow got (connect-only vs full trade) and every BLOCKED item with
the exact CTO endpoint needed. Commit evidence to a branch if you have repo write.
