# MEMO — golden reference values for the staging comparison

**Purpose:** the exact, machine-produced numbers the staging deployment must reproduce, with
provenance, tolerances, and a *do-not-false-flag* list. Do not eyeball; pair every staging number
with the golden value below and record the delta. All values are from the reference build
`builds/HEAD_temporal_mvp_v28_lens.html` (md5 `5ce1a76c7b75ec3763fda6df9538a841`) and are
re-derivable by running `harness/lens_selfcheck.js` (41 checks) + `harness/a16_atm_gate.js` (5),
whose full output is `golden/GOLDEN_harness_output.txt` (**41 PASS / 0 FAIL + 5 PASS / 0 FAIL**).

Notation: `γ` = base curve exponent = `w/(1−w)` at the live weight; `m` = steepness knob (m=1 = plain
v24 curve); the lensed option-value exponent is `g = g_loc = m·γ`, constant at every strike.

## 1. Option value + American exercise seam (PORT item 1)
Put, strike K=$100.

| quantity | m=1 (g=γ=2) | m=3 (g=6) | formula | provenance |
|---|---|---|---|---|
| exercise/settlement line S* (put) | **$66.67** (=⅔K) | **$85.71** (=6⁄7K) | `S* = K·g/(g+1)` | changelog item 1; lens_selfcheck O1/CM4-v2 |
| value at S* | **1/3** | **1/7** | `1/(g+1)` | seam value |
| value at-the-money (S=K) | **0.148** | **0.057** | `1/((g+1)·((g+1)/g)^g)` | a16_atm_gate A16.2 |
| call exercise line | $150 (=3⁄2K) | $116.7 (=7⁄6K) | `K·(g+1)/g` | CM4-v2 call seam |

**Hard invariant (must always hold):** value ≥ intrinsic everywhere (`markLensed ≥ max(0, put/call payoff)`).
Provenance: lens_selfcheck CM10 (`value_ge_intrinsic`). Tolerance: value must never be < intrinsic at 4dp.

## 2. Trade warps the curve at the trade point (PORT item 2)
Pool `(x=10 units, y=10 cash, w=0.5)`, trade at ray θ=4, cash-in `dy=+1`:

| quantity | golden | tolerance | provenance |
|---|---|---|---|
| new weight w′ | **11/21 = 0.52380952…** | exact (≤1e-15) | lens_selfcheck CM8-v2.2 |
| x′ | **215/22 = 9.7727…** | ≤1e-13 | CM8-v2.2 |
| y′ | **11** | exact | CM8-v2.2 |
| Δx | **−5/22 = −0.22727…** | ≤1e-15 | CM8-v2.2 |
| α, β at the trade point | **conserved, Δα=Δβ=0** | machine-eps (full precision — NOT rounded) | trade-point law |

**NOT `22/43` (naive) and NOT `6/11` (old reserve-point).** If staging gives 22/43 or 6/11 it is an
OLDER build, not H3. (This is the single load-bearing check — the other session confirmed Δα=Δβ=0 only
after saving **full-precision** reads to file; at rounded precision β looked like it moved 0.14. Do the
same: dump full-precision before/after amm-status to files and compute the delta from the files.)

## 3. Funding = ray deviation / curve skew (PORT item 5) — INPUT ONLY, not the rate
- On a **balanced pool (w=0.5)**: funding deviation = **0 at every strike** (the killer check). Provenance:
  lens_selfcheck FS.2b. If staging shows any non-zero funding on a symmetric/balanced pool → **REGRESSION**.
- **0 at-the-money** (ρ=1 ⇒ ln 1 = 0) and **0 in-the-money** (OTM-gated). Provenance: FE.1/FE.4.
- On a **skewed pool**: `dev = |c · ln(θ/mode)|`, `c = (g_anchor − g)/(g_anchor+1)`, `g = m·γ` (pool),
  `g_anchor = m` (balanced). Grows with skew and with m (saturating toward γ−1).
- The staging UI column should read **"Funding (ray dev; TBD)"** or equivalent — the label is the
  DEVIATION placeholder, **not a funding rate**.

## 4. Close = one sell-back path (PORT item 4)
Every leg (ITM and OTM) closes by selling back through the pool; payout is the option value computed
**before** the pool trade; payout is continuous across the strike (**no ~½ jump**). The prior model
(`temporal_mvp_v28_lens_twocaseclose.html`, bundled) has the two-case branch and the jump — use it
to identify whether staging still runs the OLD close.

---

## DO NOT FALSE-FLAG (intentional; not defects)
1. **No funding rate number** — this build ships only the deviation INPUT; the rate formula + cap are TBD (update-2).
2. **No funding cash actually moving** between sides — metered/shown only; the transfer is TBD (update-2).
3. **A tiny pool shortfall after open→close** (~trade-size²) — documented, non-extractable; the "charge-back"
   that zeroes it is TBD (update-2). See `reference_docs/UPDATE2_TBD_spec.md`.
4. **Staging is a separate port** (CTO's Go backend) and MAY LAG this build — report divergences as
   observations with evidence; do not assume a divergence is a bug.
5. Vocabulary: the funding input is **"ray deviation / curve skew"**, never "lean".

## KNOWN STAGING-SIDE GAP (from the first E2E attempt)
Staging exposed **per-band** values but **no full-curve / per-strike endpoint**, so the exact option-value
constants (§1: $66.67 / 0.148 / seams) and the steepness `m`/`γ` could not be pinned from the UI/API.
If that endpoint still isn't exposed, mark §1 checks **BLOCKED — needs a per-strike/curve endpoint from
the CTO**, do NOT PASS/FAIL them by eyeball. §2 (trade w′) and §3 (balanced-pool funding=0) are pinnable
from amm-status reads and are the priority.
