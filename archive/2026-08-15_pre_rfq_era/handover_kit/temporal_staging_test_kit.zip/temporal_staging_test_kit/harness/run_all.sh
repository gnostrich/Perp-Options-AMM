#!/bin/sh
# Validate a build: integrity (md5 + blobs) + parse/gates + slope finding + slippage.
# Run from the engine/ package root:  sh verify/run_all.sh [path-to-build.html]
# With no arg it validates the canonical HEAD; the file-safety hook passes the edited file.
set -e
HEAD=${1:-builds/HEAD_temporal_mvp_v28_lens.html}
echo "================ integrity ================"
echo -n "whole-file md5 (want 5ce1a76c7b75ec3763fda6df9538a841 for v28-lens HEAD (VOCAB SCRUB 2026-07-08 of abd35f4b [operator entries 474/476: term \"lean\"->\"skew / ray deviation\", TEXT-ONLY relabel of Funding column header \"Funding (ray dev; TBD)\" + tooltip + units-note \"SKEW DEVIATION\" + 7 engine comments; NO logic/numeric/signature change; blobs canonical; gates 41+5 unchanged; vocab_gate.sh engine-visible clean]. Prior abd35f4b = FUNDING same-slope DEVIATION placeholder 2026-07-08 of bb2f8230 [SPEC_funding_sameslope_2026-07-07; operator entries 460/462, RULED 460; R6 scope-gate CLEARED]: fundingPerStrike WEIGHT replaced — old ext·(S−1)/S magnitude (moneyness/value weight × pool-vs-ORACLE gap; funded a symmetric w=½ pool = the recurring ~20–30× regression) → the REAL same-slope pool-vs-anchor RAY-ANGLE-RATIO deviation dev=|c·ln(θ/mode)|, c=(g_a−g)/(g_a+1), g=gLoc=m·γ (pool), g_a=m (anchor w=½); OTM-gated (0 ITM), 0 at ATM (ρ=1), 0 ∀OTM on a w=½ pool (pool-lean signature). ±g wing sign/scale KEPT. DEVIATION-ONLY PLACEHOLDER — the funding FORMULA (cap/HL/interest) is DEFERRED to UPDATE-2 (entry 462); NO cap, NO new knob; (S−1) removal framed as REGRESSION-removed-from-placeholder, NOT final/oracle-independent-decided (operator-tier OPEN F1). UI: Funding column header + units-note re-labelled 'Funding (lean; TBD)' placeholder disclosure (live-rendered). Gates lens_selfcheck 41 [FE.2 hump-at-ATM + FE.3 ext·(S−1)/S source RETIRED (encoded the regression) → FS.1–FS.6 added, negative-controlled: FS.2b anti-regression KILLER (0 on symmetric pool OTM); old ext FAILS FS.1, moneyness proxy FAILS FS.2b; + RB.1–RB.6 REBASE anti-regression LOCK added 2026-07-08 (operator entry 466, .js-only — engine HTML UNCHANGED): rebase gauge-invariance (pool-intrinsic degrees, bit-exact bookkeeping β-killer, carried-strike θ→θ/r, group/identity/inverse, trade-commute SPOT+tradeUpdateAt, funding rebase-silence + symmetric-w=½-pool-zero KILLER), each negative-controlled in-gate vs 5 transform mutants + moneyness-funding] + a16 5. closeBand UNTOUCHED. Prior UPDATE-1 unified sell-back close + funding-on-extrinsic 2026-07-07 of 513425747 [SPEC_update1_clean_close; operator entries 450/452; skeptic HALT-LIFTED]: closeBand two-case branch → ONE sell-back path — BOTH legs valued at the pre-close snapshot s0 via legPrice, BOTH legs LIVE reverse-trade via tradeUpdateAt @ rho_close=(K_tx/oNow)/getSNorm(s) ⇒ Δy round-trips EXACT, Δx = documented pool-internal-reprice drain ∝dy² credited to NO wallet (credit wrapper byte-unchanged ⇒ non-extractable by construction; drain tracks the oracle/IL-like, one-signed only at fixed oracle; ~53 USD at N=0.05 exhibit). revertArc + arc storage KEPT but DORMANT (UPDATE-2 charge-back). Funding WEIGHT full-mark → EXTRINSIC markLensed−max(intrinsic,0) ⇒ zero past S* (funding ZERO ITM), single hump at ATM, ±g·(S−1)/S SIGN unchanged. Gates lens_selfcheck 31 [CM6-v2 frozen-arc round-trip + no-free-money RETIRED → CM6-v3 drain-documented + CM12 payout-continuity + FE funding-extrinsic; all negative-controlled, old two-case build 24 PASS/7 FAIL] + a16 5. Revert twin temporal_mvp_v28_lens_twocaseclose.html = 513425747. Prior -FPNL-NEGZERO display fix 2026-07-07 of 4bc939ec [tester finding, DIFF_LEDGER 4bc939ec entry; last agreed fix pre-CTO-handover, entry 427]: negative-zero guard at the 3 funding display cells — bandFundingPnl = stored===0 ? 0 : -stored (band+total rows) and c.funding===0 ? 0 : -c.funding (component row) BEFORE fmtNum, so a fresh band renders 0.000000 not -0.000000; fmtNum itself untouched; 2-line display-layer diff, engine+state script blocks byte-identical to 4bc939ec. Prior FUNDING-P/L column slice 2026-07-03 of 0e0a0062 [operator entry 425; R6 scope-gate #2; display/read layer ONLY — engine+state script blocks byte-identical to 0e0a0062]: portfolio bands-table Funding column now displays the SIGNED P/L effect = −Σ stored trader-pays accruals (+ received / − paid) at band/component/total rows; Total-row line P/L = L₀·raw_net·equity + fundingP/L×oracle (funding-INCLUSIVE, disclosed: close cash settles EX-funding until the transfer layer ships); header+units-note disclosure captions. Prior CAPTION/COMMENT slice 2026-07-02 of e148c9b7 [same trade-point campaign, second slice; strings/comments ONLY, zero behavior]: -TP339-CAPTION Invariant-Watch + Pool-State strings now state the trade-point (α_T,β_T) law with machine-epsilon scoped to ρ=1 paths + arc round-trips; R6-item-3 stale comments fixed (entry-289 vol direction ×2, closeBand barrier-era saturation paragraph — v28 correction paragraph preserved); R6-item-4/325-F chart-2 unit label %→fraction. Prior TRADE-POINT conservation 2026-07-02 of 7015c22c [operator entry 339, go 377; spec SPEC_tradepoint_conservation_2026-07-02]: live trade path = tradeUpdateAt at T=ray∩curve [paper Eq. 2; exhibit w′=11/21], frozen-ARC close revertArc, trade-point depth guard w·y·ρ^w, per-leg preview animation; SPOT trio byte-identical to v24; revert twin temporal_mvp_v28_lens_reservepoint.html = 7015c22c; gates lens_selfcheck 24 + a16 5); 928cde1cccb0f35fdc9a23a7634414c8 for demoted v27 (W); 6cc73563779a3e030774b7597d0ae187 for demoted GH v26c): "; md5sum "$HEAD" | awk '{print $1}'
# Blob check is LINE-AGNOSTIC (the two longest lines ARE the blobs; their line numbers may
# shift with edits above them — v27 svg moved 1060->1064 — but the line-md5s are canonical).
BLOBQ=$(awk '{print length($0), NR}' "$HEAD" | sort -nr | head -2 | while read len nr; do sed -n "${nr}p" "$HEAD" | md5sum | awk '{print $1}'; done | sort | tr '\n' ' ')
echo "blob line-md5 multiset (want ab663f5c26f2a461c5b0ef1421d0ad74 c505b08ad0e4c6b0fb9e64e9679fe291): $BLOBQ"
[ "$BLOBQ" = "ab663f5c26f2a461c5b0ef1421d0ad74 c505b08ad0e4c6b0fb9e64e9679fe291 " ] || { echo "BLOB CHECK FAILED"; exit 1; }

# ── v28 POLAR-LENS dispatch (Stage 1 read layer / Stage 2 write-settle) ──
# A lens build exports markLensed/gLoc (off the plain v24 base; no ghCalibrate,
# no wField). Gate it with lens_selfcheck.js [HARD GATE]: the CM-series checks
# (41 as of the REBASE anti-regression LOCK on HEAD abd35f4b, unchanged through the
# VOCAB SCRUB 5ce1a76c (text-only) - CM1-CM11 incl.
# CM4-v2 linear seams, CM10 value>=intrinsic, CM11 wing power-law, CM8-v2
# trade-point exhibit + routing negative-control, CM6-v3 drain-documented
# (frozen-arc round-trip RETIRED) + CM12 payout-continuity + FE.1/FE.4
# funding-ITM-zero + FS.1-FS.6 same-slope deviation [FE.2 hump / FE.3 ext·(S−1)/S
# RETIRED] + RB.1-RB.6 rebase gauge-invariance LOCK (operator entry 466; every
# normalized/economic quantity invariant under rebase to machine-eps, trade-commute,
# group/identity/inverse, funding rebase-silence + symmetric-pool-zero KILLER; each
# negative-controlled in-gate against 5 transform mutants + moneyness-funding); the
# .js is the authoritative list). SKIPs Stage-2-class checks on a read-only build. Routed BEFORE the (W) branch since lens builds also lack ghCalibrate.
if grep -q "function markLensed" "$HEAD" && ! grep -q "function wField" "$HEAD"; then
  echo ""
  echo "================ v28 polar-lens build -> lens_selfcheck.js [HARD GATE] ================"
  node verify/lens_selfcheck.js "$HEAD"
  echo ""
  echo "================ A16 no-jump ATM position-value gate -> a16_atm_gate.js [HARD GATE] ================"
  # Locks the live held-position value path (markEff/legValueUnified/pfComponents
  # via markLensed) continuous across the OTM↔ITM (ATM g_loc→0) crossing — no jump,
  # no regime branch in the value. Distinct from lens_selfcheck (4) (the S* seam).
  # SKIPs-as-pass on a non-lens build. set -e => any FAIL aborts run_all.
  node verify/a16_atm_gate.js "$HEAD"
  echo ""
  echo "================ controlled-vocabulary gate -> vocab_gate.sh [HARD GATE] ================"
  # Operator entry 474: no unendorsed/duplicative terminology ("lean"->"skew / ray
  # deviation"; "curvature knob"->"steepness knob") in current deliverables (handover/,
  # submitted paper v2.tex) or engine user-visible strings. Registry: docs/VOCABULARY.md.
  # Scans repo deliverables (not just $HEAD); advisory-internal hits do NOT fail. set -e
  # => a gating hit aborts run_all. Lean-prover-safe matcher.
  sh verify/vocab_gate.sh
  echo ""
  # ════════════════ REPORT-ONLY (NOT GATING) ════════════════
  # monolith_consistency.js — ACTIVE theory↔impl consistency layer (operator
  # entries 243/153#9; skeptic R6 scope-gate a04465ae WITH RIDERS). Cross-checks
  # the engine's NUMBERS against the monolith Lean formulas (MonolithConstM.lean)
  # and prints a `Lean thm ⟺ engine — PASS/FAIL` table tagged per line.
  # ⚠ THIS IS NOT A HARD GATE. It EXITS 0 ALWAYS (the `|| true` belt-and-braces
  # ensures it can NEVER abort run_all's `set -e`). The HARD gates above
  # (lens_selfcheck 41 + a16_atm_gate 5) are the bar; a green report line here
  # is NOT the gate (#5/#6/#8 are table-marked already-HARD-via-CM# cross-refs).
  # Honest ceiling: cross-checks NUMBERS (engine ⟺ Lean formula); does NOT make
  # Lean "verified" and does NOT prove the engine IS the Lean object.
  echo "================ REPORT-ONLY (NOT GATING) — monolith_consistency.js (engine ⟺ Lean numbers) ================"
  node verify/monolith_consistency.js "$HEAD" || true
  echo ""
  echo "lens build green. (GH/(W) suites N/A here. Monolith table above is REPORT-ONLY, not a gate.)"
  exit 0
fi

# ── Build-type dispatch (HEAD = v27 (W)-curve since 2026-06-10, operator entry 28) ──
# (W)/pre-GH builds (no ghCalibrate) are gated by the wcurve selfcheck [HARD GATE,
# exit 1 on any FAIL: 12 core + 9 strong-form-warp checks]. GH builds (ghCalibrate
# present, e.g. builds/temporal_mvp_v26c.html) fall through to the full GH suite.
if ! grep -q "ghCalibrate" "$HEAD"; then
  echo ""
  echo "================ (W)-curve build -> wcurve_selfcheck.js [HARD GATE] ================"
  node verify/wcurve_selfcheck.js "$HEAD"
  echo ""
  echo "(W) build green. (GH suite N/A here; pass a GH build path explicitly to exercise it.)"
  exit 0
fi

# verifiers read fixed filenames in cwd -> stage HEAD under the names they expect
SCRATCH=$(mktemp -d)
cp "$HEAD" "$SCRATCH/temporal_mvp_v26a.html"
cp "$HEAD" "$SCRATCH/temporal_mvp_v26a_2c0337e8.html"
cp "$HEAD" "$SCRATCH/temporal_mvp_v26b_itm.html"   # seam gate reads this name
cp verify/*.js "$SCRATCH/"
cd "$SCRATCH"

echo "\n================ 7 GH gates + curveTrace + marker (verify_v26a_mine.js) ================"
node verify_v26a_mine.js | grep -E "gates g=|blob-in-script|all parse|sigs|IIFE|curveTrace|marker|GATES"

echo "\n================ getMP_raw = e^ghMu * |dy/dx|  (slope_test.js) ================"
node slope_test.js | grep -E "g=|ratio"

echo "\n================ slippage acceptance targets (slip_accept.js) ================"
node slip_accept.js

echo "\n================ SPLICE-LEVEL: actual spliced functions vs targets (splice_level_check.js) ================"
node splice_level_check.js temporal_mvp_v26a.html

echo "\n================ SEAM GATE — v26b ITM/American (value+slope <=0.15% AND directional) [HARD GATE] ================"
node seam_gate.js temporal_mvp_v26b_itm.html   # set -e => nonzero exit aborts run_all

echo "\n================ DIR GATE — v26c strike-registration (crossover@K + directional consistency) [HARD GATE] ================"
node dir_gate.js temporal_mvp_v26b_itm.html    # set -e => nonzero exit aborts run_all; SKIPs as pass pre-v26c

# ── FAITH GATES (engine-faithfulness pivot, operator-ordered 2026-06-10) ──
# Hold the LIVE engine to the PROVEN constructs (formal/INDEX.md). Each gate is
# negative-controlled (--mutate flips the checked relation -> exit 1) and SKIPs
# as pass only on a pre-GH build (no ghCalibrate). set -e => any red aborts.
echo "\n================ FAITH 1 — trade = Esscher tilt translation, slope=P*e^(u-mu) (faith_esscher.js) [HARD GATE] ================"
node faith_esscher.js temporal_mvp_v26b_itm.html

echo "\n================ FAITH 2 — rebase = gauge move, sNorm-quantities invariant (faith_rebase.js) [HARD GATE] ================"
node faith_rebase.js temporal_mvp_v26b_itm.html

echo "\n================ FAITH 3 — C3 mark reflection: put = reflected call (faith_reflection.js) [HARD GATE] ================"
node faith_reflection.js temporal_mvp_v26b_itm.html

echo "\n================ FAITH 4 — gamma<->vol tie: Merton root structure + (gamma, sigma_eff) pins (faith_merton.js) [HARD GATE] ================"
node faith_merton.js temporal_mvp_v26b_itm.html

echo "\n================ FAITH 5 — curvature = variance (cgf''=Var=Fisher), engine shadow (faith_fisher.js) [HARD GATE] ================"
node faith_fisher.js temporal_mvp_v26b_itm.html

echo "\nAll checks above should be green. (Lean = trusted-from-prover; UI = tester-confirmed.)"
