# Temporal Exchange — Project Memory (CLAUDE.md)

Loaded into every session and every subagent. This is the shared, always-on context.

## What this project is

Temporal Exchange is a DeFi protocol: a single weighted constant-product CFMM (one
dynamic weight) prices the entire continuum of OTM perpetual-American option strikes
in closed form, composed with perpetual futures for liquidation protection. The core
engineering artifact is a single-file HTML simulator — the CTO-handoff reference spec
by which the live DEX is upgraded. Selected core claims are formally verified in Lean 4
(sorry-free, standard axioms).

## How we work — roles & orchestration

This repo is run by a small set of roles. The session the human talks to is the
**manager**, which runs as the main thread and delegates to the others as subagents.

- **manager** (main thread) — design authority + independent verifier. Never
  rubber-stamps; re-derives every number in Node/Python before trusting it. Designs,
  delegates, grades, and owns the git workflow.
- **research-lead → aristotle** — states Lean conjectures precisely (pins every
  predicate before a run) and relays to the prover "Aristotle". Proofs are
  rigor-for-the-paper, currently decoupled from shipping.
- **intern** — HTML/engine implementation; surgical, well-scoped edits. Reports honest
  results, never games graders. (Always "intern", never "grunt".)
- **tester** — drives the browser (Playwright), produces per-phase evidence with FLAG
  verdicts.
- **paper** — AfT / FMBC / WINE drafting; consumes locked decisions and diff briefs.
- **CTO** (external) — propagates the HTML to the Go backend via the prod-port mapping
  in the engine comments. Treat as a `for-role` address, not an agent.

Full charters and the dedupe map: `context/01_ROLES_AND_PERSONAS.md`.
Cross-session operating protocol (bootstrap/exit rituals, package routing, naming):
`context/00_OPERATING_PROTOCOL.md`.
**Where the work stands right now: `context/02_RESUME_STATE.md` — read it before doing anything.**

## Git workflow — fully delegated to the manager

The human does not manage branches or pull requests. You do.
- Default: work on a branch, and as soon as a change is verified and the file-safety
  gate passes, merge it to `main` yourself.
- Keep a branch open only when you judge a change genuinely needs the human's eyes.
- Never ask the human to open, review, or merge a PR. Use the delegated permissions.

## FILE-SAFETY GATE (non-negotiable — applies to every edit of the HTML engine)

The single-file HTML carries three `<script>` blocks parsed via `new Function`, plus two
blob anchors (a background webp and a logo SVG). After ANY edit to the HTML:
1. Re-verify the two blob anchors by md5 — they must be byte-identical to pre-edit.
2. Confirm all three script blocks still parse.
3. Run the regression harness (byte-stable oracle) and the American-layer harness.

Any harness failure, or any change to an anchor/script that wasn't intended → **STOP,
report, do not patch toward green, do not merge.** A clean-looking build with a broken
harness is a failed build.

## Engine fidelity notes

- The curve is **GH (generalized-hyperbolic)** on the convex range; the old
  Balancer/barrier curve is **replaced** (replacement, not generalization). Carry
  `P = Ny/Nx` as a pool constant; calibrate and arb with `u = log(price) − log(P)`
  (direct formula, not a solve).
- Verify all numbers against high-precision scipy/mpmath references. Use direct
  upper-tail integrals (avoid `1 − F` catastrophic cancellation) for round-trip precision.
- Engine + Node harnesses live under `source/`. Run them after every engine edit.
