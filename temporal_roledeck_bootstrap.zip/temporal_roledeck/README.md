# Temporal — RoleDeck bootstrap bundle

This is the repo skeleton that turns your multi-chat workflow into real Claude Code
subagents, with your context preserved. Everything is web-only; you never touch a terminal.

## What's in here
- `CLAUDE.md` — always-loaded project brief, git policy, and the file-safety gate.
- `.claude/settings.json` — starting git-delegation allow-rules.
- `.claude/commands/bootstrap-roles.md` — the one-shot setup command (same as the prompt below).
- `context/` — your preserved cross-chat context: the operating protocol, the deduced
  roster + dedupe map, the resume state, and digests of the five labeled sessions.

## You do NOT need to gather files to set up the agents
Your roles, state, and session history are already captured in `context/` (pulled from
your chats). The agents are created from that — uploading this bundle is enough.

### Optional: fold in your full history (one click)
claude.ai → your initials (bottom-left) → Settings → Privacy → **Export Data**. You'll
get an email with a download link (a zip of JSON). Drop that whole zip into this folder
before uploading; the bootstrap parses it for extra detail and tries to recover any
artifacts that were pasted into chats.

### The one real file you'll eventually need (later, not now)
The current **HTML engine build** lives in your Google Drive (the CTO copy), not in chat
exports. The agents are created without it; drop it into a `source/` folder only when the
intern/tester start doing engine work. Anything else you have (harnesses, spec, paper,
notes, newest `session_tree_note.md`) can go in `source/` too — the bootstrap scans it
recursively — but none of it blocks setup.

## Steps (all in the browser)
1. **Unzip** this bundle. (Optional: drop your Claude data-export zip inside it.)
2. **Create a repo** at github.com → "Add file → Upload files" → drag in the whole set
   (the uploader preserves folder structure). Commit.
3. Make sure the GitHub account is connected at **claude.ai/code** and your git
   permissions are delegated as you intend.
4. **Open a session** at claude.ai/code on that repo and paste the prompt below
   (or run `/bootstrap-roles`). It scans, dedupes your roles, creates the agents +
   seeded memory, and commits — merging to main itself.
5. When it finishes, **start a fresh session** (the `manager` is now the default agent)
   and tell it to go. It resumes from the v26a tester run / the Finding-2 decision.

## The prompt to paste

> Read CLAUDE.md, all of context/**, and all of source/**. Using context/01 as the
> starting hypothesis, confirm and DEDUPE the roles from the chat digests in
> context/chats/ — the several "manager"/"Orchestrator" sessions collapse to one
> `manager`, "OG research guy" is `research-lead`. Final roster: manager (main thread),
> research-lead, intern, tester, paper. Do not create an agent for the CTO or for
> Aristotle (fold the Lean-prover relay into research-lead).
>
> Create `.claude/agents/<name>.md` for each (valid frontmatter: name lowercase-hyphen,
> sharp action-oriented description, least-privilege tools, model: inherit,
> memory: project; body from its charter). Give `manager` the tools
> `Agent(research-lead, intern, tester, paper), Read, Edit, Write, Bash, Grep, Glob` and
> make it the default by writing "agent": "manager" into .claude/settings.json (keep the
> existing permissions). The `intern` body must restate the FILE-SAFETY GATE from CLAUDE.md.
>
> Seed `.claude/agent-memory/<name>/MEMORY.md` for each from context/02_RESUME_STATE.md
> plus role-relevant material (≤150 lines each).
>
> Git is fully delegated: commit everything and merge to main yourself — never ask me to
> manage a PR.
>
> Then report: the final roster + your dedupe decisions, every file created, and the
> single concrete next action to resume from where we are (per context/02: the v26a
> tester run + surfacing the Finding-2 decision). Don't edit the HTML engine in this run.

That's it — paste, approve, start a fresh session, and you're running on real agents.
